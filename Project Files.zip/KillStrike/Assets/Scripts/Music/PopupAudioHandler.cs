using UnityEngine;

public class PopupAudioHandler : MonoBehaviour
{
    public AudioSource audioSource;

    public AudioClip confirmSound;
    public AudioClip cancelSound;

    public void PlayConfirmSound()
    {
        if (audioSource && confirmSound)
        {
            audioSource.PlayOneShot(confirmSound);
        }
    }

    public void PlayCancelSound()
    {
        if (audioSource && cancelSound)
        {
            audioSource.PlayOneShot(cancelSound);
        }
    }
}
