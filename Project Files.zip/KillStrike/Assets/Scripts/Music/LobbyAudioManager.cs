using UnityEngine;

public class LobbyAudioManager : MonoBehaviour
{
    public AudioSource musicSource;
    public AudioSource sfxSource;

    public AudioClip mainMusic;
    public AudioClip panelMusic;
    public AudioClip buttonClickSFX;

    private AudioClip currentMusic;

    void Start()
    {
        PlayMainMusic();
    }

    public void PlayMainMusic()
    {
        if (mainMusic != null && musicSource != null)
        {
            musicSource.clip = mainMusic;
            musicSource.loop = true;
            musicSource.Play();
            currentMusic = mainMusic;
        }
    }

    public void PlayPanelMusic()
    {
        if (panelMusic != null && musicSource != null && currentMusic != panelMusic)
        {
            musicSource.clip = panelMusic;
            musicSource.loop = true;
            musicSource.Play();
            currentMusic = panelMusic;
        }
    }

    public void PlayButtonClick()
    {
        if (sfxSource != null && buttonClickSFX != null)
        {
            sfxSource.PlayOneShot(buttonClickSFX);
        }
    }
}
