using Unity.Netcode;
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public enum MusicState
{
    None,
    Countdown,
    MainGame,
    GameOver
}

public enum SoundEffectType
{
    A,
    B,
    Dropkick,
    C,
    D,
    Jump,
    Land,
    Dash,
    Walk,
    Run,
    Kill,
    Death
}

public class MusicManager : NetworkBehaviour
{
    public static MusicManager Instance { get; private set; }

    [Header("Music")]
    [SerializeField] private AudioSource _musicSource;
    [SerializeField] private AudioClip _countdownMusic;
    [SerializeField] private AudioClip _mainGameMusic;
    [SerializeField] private AudioClip _gameOverMusic;

    [Header("Sound Effects")]
    [SerializeField] private AudioSource _sfxSourcePrefab;
    [SerializeField] private int _initialPoolSize = 10;
    [SerializeField] private float _spatialBlend = 0.8f;
    [SerializeField] private float _minDistance = 5f;
    [SerializeField] private float _maxDistance = 50f;

    [Header("Sound Effect Clips")]
    [SerializeField] private AudioClip _A;
    [SerializeField] private AudioClip _B;
    [SerializeField] private AudioClip _dropkick;
    [SerializeField] private AudioClip _C;
    [SerializeField] private AudioClip _D;
    [SerializeField] private AudioClip _jump;
    [SerializeField] private AudioClip _land;
    [SerializeField] private AudioClip _dash;
    [SerializeField] private AudioClip _walk;
    [SerializeField] private AudioClip _run;
    [SerializeField] private AudioClip _kill;
    [SerializeField] private AudioClip _death;

    public AudioClip buttonClickSFX;

    private NetworkVariable<MusicState> _currentMusicState = new NetworkVariable<MusicState>();
    private Queue<AudioSource> _sfxPool = new Queue<AudioSource>();
    private Dictionary<SoundEffectType, AudioClip> _sfxClips = new Dictionary<SoundEffectType, AudioClip>();

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public override void OnDestroy()
    {
        base.OnDestroy();

        if (Instance == this)
        {
            Instance = null;
        }

        // Stop all coroutines
        StopAllCoroutines();

        // Clean up audio sources
        foreach (var source in _sfxPool)
        {
            if (source != null)
            {
                source.Stop();
                Destroy(source.gameObject);
            }
        }
        _sfxPool.Clear();
    }

    private void InitializeSfxDictionary()
    {
        _sfxClips.Clear();

        _sfxClips[SoundEffectType.A] = _A;
        _sfxClips[SoundEffectType.B] = _B;
        _sfxClips[SoundEffectType.Dropkick] = _dropkick;
        _sfxClips[SoundEffectType.C] = _C;
        _sfxClips[SoundEffectType.D] = _D;
        _sfxClips[SoundEffectType.Jump] = _jump;
        _sfxClips[SoundEffectType.Land] = _land;
        _sfxClips[SoundEffectType.Dash] = _dash;
        _sfxClips[SoundEffectType.Walk] = _walk;
        _sfxClips[SoundEffectType.Run] = _run;
        _sfxClips[SoundEffectType.Kill] = _kill;
        _sfxClips[SoundEffectType.Death] = _death;
    }

    private void InitializeSfxPool()
    {
        for (int i = 0; i < _initialPoolSize; i++)
        {
            CreateNewPooledSource();
        }
    }

    private AudioSource CreateNewPooledSource()
    {
        AudioSource source = Instantiate(_sfxSourcePrefab, transform);
        source.spatialBlend = _spatialBlend;
        source.minDistance = _minDistance;
        source.maxDistance = _maxDistance;
        source.gameObject.SetActive(false);
        _sfxPool.Enqueue(source);
        return source;
    }

    public override void OnNetworkSpawn()
    {
        InitializeSfxPool();

        if (IsServer)
        {
            InitializeSfxDictionary();
            _currentMusicState.Value = MusicState.None;
        } else if (IsClient)
        {
            RequestSfxDictionaryServerRpc();
        }

        // Sync music for late-joining clients
        _currentMusicState.OnValueChanged += OnMusicStateChanged;
        OnMusicStateChanged(MusicState.None, _currentMusicState.Value);
    }

    [ServerRpc(RequireOwnership = false)]
    private void RequestSfxDictionaryServerRpc(ServerRpcParams rpcParams = default)
    {
        ClientRpcParams clientParams = new ClientRpcParams
        {
            Send = new ClientRpcSendParams
            {
                TargetClientIds = new ulong[] { rpcParams.Receive.SenderClientId }
            }
        };
        SyncSfxDictionaryClientRpc(clientParams);
    }

    [ClientRpc]
    private void SyncSfxDictionaryClientRpc(ClientRpcParams rpcParams = default)
    {
        InitializeSfxDictionary();
    }

    private void OnMusicStateChanged(MusicState previous, MusicState current)
    {
        PlayMusicLocal(current);
    }

    #region Music Control
    public void PlayCountdownMusic()
    {
        if (IsServer) _currentMusicState.Value = MusicState.Countdown;
    }

    public void PlayMainGameMusic()
    {
        if (IsServer) _currentMusicState.Value = MusicState.MainGame;
    }

    public void PlayGameOverMusic()
    {
        if (IsServer) _currentMusicState.Value = MusicState.GameOver;
    }

    private void PlayMusicLocal(MusicState state)
    {
        switch (state)
        {
            case MusicState.Countdown:
                _musicSource.clip = _countdownMusic;
                break;
            case MusicState.MainGame:
                _musicSource.clip = _mainGameMusic;
                break;
            case MusicState.GameOver:
                _musicSource.clip = _gameOverMusic;
                break;
            default:
                _musicSource.Stop();
                return;
        }

        _musicSource.loop = true;
        _musicSource.Play();
    }
    #endregion

    #region Sound Effects
    // For global sounds (heard by all players)
    public void PlaySoundEffect(SoundEffectType type, Vector3 position)
    {
        if (type == SoundEffectType.Death)
        {
            Debug.LogError("Death sounds should be played locally using PlayLocalSoundEffect");
            return;
        }

        PlaySoundLocal(type, position);

        if (IsServer)
        {
            PlaySoundForOthersClientRpc(type, position, NetworkManager.Singleton.LocalClientId);
        }
        else
        {
            PlaySoundServerRpc(type, position);
        }
    }

    // For local-only sounds (like death sounds)
    public void PlayLocalSoundEffect(SoundEffectType type, Vector3 position)
    {
        if (type == SoundEffectType.Death)
        {
            // Handle death sound locally
            PlaySoundLocal(type, position);
        }
        else
        {
            Debug.LogWarning($"Sound {type} should be played globally. Use PlaySoundEffect instead.");
        }
    }

    [ServerRpc(RequireOwnership = false)]
    private void PlaySoundServerRpc(SoundEffectType type, Vector3 position, ServerRpcParams rpcParams = default)
    {
        PlaySoundForOthersClientRpc(type, position, rpcParams.Receive.SenderClientId);
    }

    [ClientRpc]
    private void PlaySoundForOthersClientRpc(SoundEffectType type, Vector3 position, ulong senderClientId)
    {
        // Skip if this client is the sender (they already played it locally)
        if (NetworkManager.Singleton.LocalClientId == senderClientId) return;

        PlaySoundLocal(type, position);
    }

    private void PlaySoundLocal(SoundEffectType type, Vector3 position)
    {
        if (!_sfxClips.ContainsKey(type))
        {
            Debug.LogWarning($"Missing sound clip for {type}");
            return;
        }

        AudioSource source = GetPooledAudioSource();
        source.transform.position = position;
        source.clip = _sfxClips[type];
        source.Play();
        ReturnToPoolAfterPlay(source);
    }

    private AudioSource GetPooledAudioSource()
    {
        if (_sfxPool.Count == 0)
        {
            CreateNewPooledSource();
        }

        AudioSource source = _sfxPool.Dequeue();
        source.gameObject.SetActive(true);
        return source;
    }

    private void ReturnToPoolAfterPlay(AudioSource source)
    {
        StartCoroutine(ReturnWhenFinished(source));
    }

    private System.Collections.IEnumerator ReturnWhenFinished(AudioSource source)
    {
        yield return new WaitWhile(() => source.isPlaying);
        source.gameObject.SetActive(false);
        _sfxPool.Enqueue(source);
    }
    #endregion

    public void PlayButtonClick()
    {
        if (_sfxSourcePrefab != null && buttonClickSFX != null)
        {
            _sfxSourcePrefab.PlayOneShot(buttonClickSFX);
        }
    }
}