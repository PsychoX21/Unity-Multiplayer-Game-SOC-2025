using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;
using System.Linq;

public class PlayerCombat : NetworkBehaviour
{
    [Header("Combat Settings")]
    public CombatData combatData;
    public Transform attackPoint;
    public Transform dropKickPoint;
    public Transform windSlashPoint;
    public GameObject windSlashPrefab;

    [Header("Hitboxes")]
    public GameObject punchHitbox;
    public GameObject kickHitbox;
    public GameObject dropKickHitbox;
    public GameObject swordHitbox;
    public GameObject swordAirHitbox;

    // Combat states
    public bool IsAttacking { get; private set; }
    public bool IsSwordDrawn { get; private set; }
    public bool IsChargingWindSlash { get; private set; }
    public bool IsDropKicking { get; private set; }

    // Timers
    private float _attackCooldownTimer;
    private float _windSlashChargeTimer;
    private float _dropKickDurationTimer;

    // Combo Tracking
    private int _punchComboCount;
    private int _kickComboCount;
    private int _swordComboCount;
    private int _swordAirComboCount;

    private float _punchComboWindowTimer;
    private float _kickComboWindowTimer;
    private float _swordComboWindowTimer;
    private float _swordAirComboWindowTimer;

    private float punchComboWindow = 0.8f;
    private float kickComboWindow = 0.8f;
    private float swordComboWindow = 0.8f;
    private float swordAirComboWindow = 0.8f;
    private float punchComboCooldown = 1.1f;
    private float kickComboCooldown = 1.1f;
    private float swordComboCooldown = 1.1f;
    private float swordAirComboCooldown = 1.1f;

    // Input buffering
    private bool _bufferedPunch;
    private bool _bufferedKick;
    private bool _bufferedSwordAttack;
    private bool _bufferedSwordAirAttack;
    private float _inputBufferTime = 0.2f;
    private float _inputBufferTimer;

    // References
    private PlayerMovement _playerMovement;
    private Rigidbody2D _rb;
    private Animator _animator;
    private OwnerNetworkAnimator _netAnimator;

    private Dictionary<GameObject, Coroutine> activeAttackCoroutines = new();
    private Dictionary<string, GameObject> _hitboxIds = new();

    private void Awake()
    {
        _playerMovement = GetComponent<PlayerMovement>();
        _rb = GetComponent<Rigidbody2D>();
        _animator = GetComponent<Animator>();
        _netAnimator = GetComponent<OwnerNetworkAnimator>();
        _hitboxIds = new Dictionary<string, GameObject>();
    }

    private void Start()
    {
        // Add hitboxes with case-insensitive keys
        RegisterHitbox("Punch", punchHitbox);
        RegisterHitbox("Kick", kickHitbox);
        RegisterHitbox("DropKick", dropKickHitbox);
        RegisterHitbox("Sword", swordHitbox);
        RegisterHitbox("SwordAir", swordAirHitbox);

        DisableAllHitboxes();
        IsSwordDrawn = false;
    }

    private void RegisterHitbox(string name, GameObject hitbox)
    {
        if (hitbox == null)
        {
            Debug.LogError($"Hitbox {name} is null!");
            return;
        }

        string key = name.ToLower(); // Use lowercase for consistency
        if (!_hitboxIds.ContainsKey(key))
        {
            _hitboxIds.Add(key, hitbox);
            Debug.Log($"Registered hitbox: {key}");
        }
        else
        {
            Debug.LogWarning($"Duplicate hitbox registration: {key}");
        }
    }

    private string GetHitboxName(GameObject hitbox)
    {
        if (hitbox == null) return "";

        foreach (var pair in _hitboxIds)
        {
            if (pair.Value == hitbox)
            {
                Debug.Log($"Found hitbox name: {pair.Key} for object {hitbox.name}");
                return pair.Key;
            }
        }

        Debug.LogError($"Hitbox not found: {hitbox.name}");
        return "";
    }

    private SoundEffectType GetRandomAttackSound()
    {
        int rand = Random.Range(0, 4);
        return rand switch
        {
            0 => SoundEffectType.A,
            1 => SoundEffectType.B,
            2 => SoundEffectType.C,
            _ => SoundEffectType.D,
        };
    }

    private void Update()
    {
        if (UserInput.instance == null || GameManager.Instance != null && !GameManager.Instance.gameStarted.Value)
        {
            ForceDisableAllHitboxes();
            return;
        }

        if (!IsOwner) return;

        if (_playerMovement.IsDashing || _playerMovement.IsSliding) { return; }
        HandleCombatInput();
        UpdateTimers();
        CheckBufferedInputs();
        if (IsSwordDrawn) AddWindSlashCharge(Time.deltaTime);
    }

    private void HandleCombatInput()
    {
        // Add null check
        if (UserInput.instance == null || UserInput.instance.controls == null)
            return;

        if (UserInput.instance.controls.Combat.Punch.WasPressedThisFrame())
        {
            if (IsSwordDrawn)
            {
                if (_playerMovement.LastOnGroundTime > 0)
                {
                    if (CanStartAttack(combatData.swordCooldown)) SwordAttack();
                    else BufferInput(ref _bufferedSwordAttack);
                }
                else
                {
                    if (CanStartAttack(combatData.swordAirCooldown)) SwordAirAttack();
                    else BufferInput(ref _bufferedSwordAirAttack);
                }
            }
            else
            {
                if (CanStartAttack(combatData.punchCooldown))
                    Punch();
                else
                    BufferInput(ref _bufferedPunch);
            }
        }

        if (UserInput.instance.controls.Combat.Kick.WasPressedThisFrame())
        {
            if (_playerMovement.LastOnGroundTime > 0)
            {
                if (CanStartAttack(combatData.kickCooldown))
                    Kick();
                else
                    BufferInput(ref _bufferedKick);
            }
            else if (UserInput.instance.moveInput.y < -0.3f)
            {
                DropKick();
            }
            else
            {
                if (CanStartAttack(combatData.kickCooldown))
                    Kick();
                else
                    BufferInput(ref _bufferedKick);
            }
        }

        if (UserInput.instance.controls.Combat.SwordAction.WasPressedThisFrame())
        {
            ToggleSword();
        }

        //if (UserInput.instance.controls.Combat.WindSlash.WasPressedThisFrame() &&
        //    _windSlashChargeTimer >= combatData.windSlashChargeRequired)
        //{
        //    WindSlash();
        //}
    }

    private bool CanStartAttack(float cooldown)
    {
        return !IsAttacking && _attackCooldownTimer <= 0 && !_playerMovement.IsDashing && !_playerMovement.IsSliding;
    }

    private void BufferInput (ref bool bufferFlag)
    {
        bufferFlag = true;
        _inputBufferTimer = _inputBufferTime;
    }

    private void ResetBuffers()
    {
        _bufferedPunch = false;
        _bufferedKick = false;
        _bufferedSwordAttack = false;
        _bufferedSwordAirAttack = false;
    }

    private void CheckBufferedInputs()
    {
        if (_inputBufferTimer > 0)
        {
            _inputBufferTimer -= Time.deltaTime;

            if (_inputBufferTimer <= 0) ResetBuffers();
            else if (_attackCooldownTimer <= 0 && !IsAttacking)
            {
                if (_bufferedPunch)
                {
                    ResetBuffers();
                    Punch();
                }
                else if (_bufferedKick)
                {
                    ResetBuffers();
                    Kick();
                }
                else if (_bufferedSwordAttack)
                {
                    ResetBuffers();
                    if (_playerMovement.LastOnGroundTime > 0) SwordAttack();
                    else SwordAirAttack();
                }
                else if (_bufferedSwordAirAttack)
                {
                    ResetBuffers();
                    SwordAirAttack();
                }
            }
        }
    }

    private void UpdateTimers()
    {
        if (_attackCooldownTimer > 0) _attackCooldownTimer -= Time.deltaTime;
        if (IsChargingWindSlash) _windSlashChargeTimer += Time.deltaTime;
        if (IsDropKicking) _dropKickDurationTimer -= Time.deltaTime;

        UpdateComboTimer(ref _punchComboWindowTimer, ref _punchComboCount);
        UpdateComboTimer(ref _kickComboWindowTimer, ref _kickComboCount);
        UpdateComboTimer(ref _swordComboWindowTimer, ref _swordComboCount);
        UpdateComboTimer(ref _swordAirComboWindowTimer, ref _swordAirComboCount);
    }

    private void UpdateComboTimer(ref float timer, ref int comboCount)
    {
        if (timer > 0)
        {
            timer -= Time.deltaTime;
            if (timer <= 0)
            {
                comboCount = 0;
            }
        }
    }

    #region ATTACK METHODS
    private void Punch()
    {
        if (IsAttacking || _attackCooldownTimer > 0 || _playerMovement.IsDashing) return;
        if (MusicManager.Instance != null) MusicManager.Instance.PlaySoundEffect(GetRandomAttackSound(), transform.position);

        bool isCombo = _punchComboWindowTimer > 0;
        _punchComboCount = isCombo ? _punchComboCount + 1 : 1;
        _punchComboCount = Mathf.Clamp(_punchComboCount, 1, 3);

        _punchComboWindowTimer = punchComboWindow;

        StartCoroutine(PerformAttack(
                punchHitbox,
                combatData.punchDuration,
                _punchComboCount == 3 ? punchComboCooldown : combatData.punchCooldown,
                "Punch" + _punchComboCount,
                null,
                () =>
                {
                    if (_punchComboCount >= 3)
                    {
                        _punchComboCount = 0;
                    }
                }
            ));
    }

    private void Kick()
    {
        if (IsAttacking || _attackCooldownTimer > 0 || _playerMovement.IsDashing) return;
        if (MusicManager.Instance != null) MusicManager.Instance.PlaySoundEffect(GetRandomAttackSound(), transform.position);

        bool isCombo = _kickComboWindowTimer > 0;
        _kickComboCount = isCombo ? _kickComboCount + 1 : 1;
        _kickComboCount = Mathf.Clamp(_kickComboCount, 1, 2);

        _kickComboWindowTimer = kickComboWindow;

        StartCoroutine(PerformAttack(
            kickHitbox,
            combatData.kickDuration,
            _kickComboCount == 2 ? kickComboCooldown : combatData.kickCooldown,
            "Kick" + _kickComboCount,
            null,
            () => {
                if (_kickComboCount >= 2)
                {
                    _kickComboCount = 0;
                }
            }
        ));
    }

    private void DropKick()
    {
        if (IsAttacking || _playerMovement.IsDashing) return;
        if (MusicManager.Instance != null) MusicManager.Instance.PlaySoundEffect(SoundEffectType.Dropkick, transform.position);

        IsDropKicking = true;
        _dropKickDurationTimer = combatData.dropKickDuration;

        _rb.linearVelocity = new Vector2(_rb.linearVelocity.x, -combatData.dropKickForce);
        SetGravityScale(combatData.dropKickGravityScale);

        StartCoroutine(PerformAttack(
            dropKickHitbox,
            combatData.dropKickDuration,
            combatData.dropKickCooldown,
            "DropKick",
            null,
            () => {
                IsDropKicking = false;
                SetGravityScale(_playerMovement.Data.gravityScale);
            }
        ));
    }

    private void SwordAttack()
    {
        if (IsAttacking || _attackCooldownTimer > 0 || _playerMovement.IsDashing) return;
        if (_playerMovement.LastOnGroundTime <= 0) return;
        if (MusicManager.Instance != null) MusicManager.Instance.PlaySoundEffect(GetRandomAttackSound(), transform.position);

        bool isCombo = _swordComboWindowTimer > 0;
        _swordComboCount = isCombo ? _swordComboCount + 1 : 1;
        _swordComboCount = Mathf.Clamp(_swordComboCount, 1, 3);

        _swordComboWindowTimer = swordComboWindow;

        StartCoroutine(PerformAttack(
            swordHitbox,
            combatData.swordDuration,
            _swordComboCount == 3 ? swordComboCooldown : combatData.swordCooldown,
            "SwordAttack" + _swordComboCount,
            null,
            () => {
                if (_swordComboCount >= 3)
                {
                    _swordComboCount = 0;
                }
            }
        ));
    }

    private void SwordAirAttack()
    {
        if (IsAttacking || _playerMovement.IsDashing) return;
        if (MusicManager.Instance != null) MusicManager.Instance.PlaySoundEffect(GetRandomAttackSound(), transform.position);

        bool isCombo = _swordAirComboWindowTimer > 0;
        _swordAirComboCount = isCombo ? _swordAirComboCount + 1 : 1;
        _swordAirComboCount = Mathf.Clamp(_swordAirComboCount, 1, 3);

        _swordAirComboWindowTimer = swordAirComboWindow;

        _rb.linearVelocity = new Vector2(_rb.linearVelocity.x, -combatData.swordAirDownForce);

        StartCoroutine(PerformAttack(
            swordAirHitbox,
            combatData.swordAirDuration,
            _swordAirComboCount == 3 ? swordAirComboCooldown : combatData.swordAirCooldown,
            "SwordAirAttack" + _swordAirComboCount,
            null,
            () => {
                if (_swordAirComboCount >= 3)
                {
                    _swordAirComboCount = 0;
                }
            }
        ));
    }

    private void WindSlash()
    {
        if (IsAttacking || _playerMovement.IsDashing) return;

        StartCoroutine(PerformWindSlash());
    }

    private IEnumerator PerformAttack(GameObject hitbox, float duration, float cooldown, string animTrigger, System.Action onStart = null, System.Action onEnd = null)
    {
        IsAttacking = true;
        _attackCooldownTimer = cooldown;

        // Animation
        if (_animator) _netAnimator.SetTrigger(animTrigger);

        onStart?.Invoke();

        // Activate hitbox using simple RPC
        string hitboxName = GetHitboxName(hitbox);
        if (!string.IsNullOrEmpty(hitboxName))
        {
            SetHitboxActiveServerRpc(hitboxName, true);
        }

        yield return new WaitForSeconds(duration);

        // Deactivate hitbox
        if (!string.IsNullOrEmpty(hitboxName))
        {
            SetHitboxActiveServerRpc(hitboxName, false);
        }

        // Special case for dropkick
        if (animTrigger == "DropKick")
        {
            IsDropKicking = false;
            SetGravityScale(_playerMovement.Data.gravityScale);
        }

        IsAttacking = false;
        onEnd?.Invoke();
    }

    #region HITBOX NETWORKING METHODS
    [ServerRpc]
    private void SetHitboxActiveServerRpc(string hitboxName, bool active)
    {
        // Normalize name to lowercase
        string key = hitboxName.ToLower();

        if (_hitboxIds.TryGetValue(key, out GameObject hitbox))
        {
            if (hitbox != null)
            {
                hitbox.SetActive(active);
                Debug.Log($"Server activated {key}: {active}");
            }
            else
            {
                Debug.LogError($"Hitbox {key} is null on server!");
            }

            // Notify owner client
            SetHitboxActiveClientRpc(key, active, new ClientRpcParams
            {
                Send = new ClientRpcSendParams
                {
                    TargetClientIds = new ulong[] { OwnerClientId }
                }
            });
        }
        else
        {
            Debug.LogError($"Server: Hitbox {key} not found! Available keys: {string.Join(", ", _hitboxIds.Keys)}");
        }
    }

    [ClientRpc]
    private void SetHitboxActiveClientRpc(string hitboxName, bool active, ClientRpcParams rpcParams = default)
    {
        string key = hitboxName.ToLower();

        if (_hitboxIds.TryGetValue(key, out GameObject hitbox))
        {
            if (hitbox != null)
            {
                hitbox.SetActive(active);
                Debug.Log($"Client activated {key}: {active}");
            }
            else
            {
                Debug.LogError($"Hitbox {key} is null on client!");
            }
        }
        else
        {
            Debug.LogError($"Client: Hitbox {key} not found! Available keys: {string.Join(", ", _hitboxIds.Keys)}");
        }
    }
    #endregion

    private IEnumerator PerformWindSlash()
    {
        IsAttacking = true;

        // Animation
        if (_animator) _netAnimator.SetTrigger("WindSlash");

        // Create projectile
        GameObject slash = Instantiate(
            windSlashPrefab,
            windSlashPoint.position,
            Quaternion.identity
        );

        // Set direction
        WindSlashProjectile projectile = slash.GetComponent<WindSlashProjectile>();
        projectile.SetDirection(_playerMovement.IsFacingRight);
        projectile.damage = combatData.windSlashDamage;

        // Reset charge
        _windSlashChargeTimer = 0;
        IsChargingWindSlash = false;

        yield return new WaitForSeconds(combatData.windSlashCooldown);
        IsAttacking = false;
    }
    #endregion

    #region UTILITY METHODS
    private void ToggleSword()
    {
        if (IsAttacking) return;

        IsSwordDrawn = !IsSwordDrawn;
        if (_animator) _animator.SetBool("SwordDrawn", IsSwordDrawn);
    }

    public void AddWindSlashCharge(float amount)
    {
        if (!IsSwordDrawn) return;

        _windSlashChargeTimer += amount;
        IsChargingWindSlash = true;

        if (_windSlashChargeTimer >= combatData.windSlashChargeRequired)
        {
            // Visual feedback when fully charged
            if (_animator) _netAnimator.SetTrigger("WindSlashCharged");
        }
    }

    private void DisableAllHitboxes()
    {
        punchHitbox.SetActive(false);
        kickHitbox.SetActive(false);
        dropKickHitbox.SetActive(false);
        swordHitbox.SetActive(false);
        swordAirHitbox.SetActive(false);
    }

    public void ForceDisableAllHitboxes()
    {
        foreach (var coroutine in activeAttackCoroutines.Values.ToList())
        {
            if (coroutine != null)
            {
                StopCoroutine(coroutine);
            }
        }
        activeAttackCoroutines.Clear();
    }

    private void SetGravityScale(float scale)
    {
        _rb.gravityScale = scale;
    }
    #endregion

    private void OnDrawGizmos()
    {
        if (punchHitbox != null && punchHitbox.activeInHierarchy)
            DrawHitboxGizmo(punchHitbox, Color.red);

        if (kickHitbox != null && kickHitbox.activeInHierarchy)
            DrawHitboxGizmo(kickHitbox, Color.green);

        if (dropKickHitbox != null && dropKickHitbox.activeInHierarchy)
            DrawHitboxGizmo(dropKickHitbox, Color.yellow);

        if (swordHitbox != null && swordHitbox.activeInHierarchy)
            DrawHitboxGizmo(swordHitbox, Color.cyan);

        if (swordAirHitbox != null && swordAirHitbox.activeInHierarchy)
            DrawHitboxGizmo(swordAirHitbox, Color.magenta);
    }

    private void DrawHitboxGizmo(GameObject hitboxObj, Color color)
    {
        Gizmos.color = color;

        var collider = hitboxObj.GetComponent<Collider2D>();
        if (collider is BoxCollider2D box)
        {
            Gizmos.matrix = hitboxObj.transform.localToWorldMatrix;
            Gizmos.DrawWireCube(box.offset, box.size);
        }
        else if (collider is CircleCollider2D circle)
        {
            Gizmos.matrix = hitboxObj.transform.localToWorldMatrix;
            Gizmos.DrawWireSphere(circle.offset, circle.radius);
        }

        Gizmos.matrix = Matrix4x4.identity; // Reset matrix
    }
}