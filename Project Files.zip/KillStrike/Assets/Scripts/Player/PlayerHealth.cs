using Unity.Netcode;
using UnityEngine;
using System.Collections;

public class PlayerHealth : NetworkBehaviour
{
    [Header("Health Settings")]
    public NetworkVariable<int> CurrentHealth = new(100);
    public int MaxHealth = 100;
    public float InvincibilityDuration = 0.5f;
    public float KnockbackForce = 1f;

    [Header("References")]
    [SerializeField] private OwnerNetworkAnimator _netAnimator;
    [SerializeField] private Rigidbody2D _rb;
    [SerializeField] private PlayerMovement _playerMovement;

    private bool _isInvincible;
    private float _invincibleTimer;
    private bool _isDead;

    [SerializeField] private SpriteRenderer _spriteRenderer;
    [SerializeField] private Color flashColor = Color.red;
    [SerializeField] private float flashDuration = 0.2f;

    [SerializeField] private float blinkDuration = 3f;
    [SerializeField] private float blinkInterval = 0.2f;

    [Header("Stats")]
    [SerializeField] private PlayerStats playerStats;

    private Coroutine _blinkCoroutine;
    private Coroutine _flashCoroutine;

    private GameObject _flashOverlay;

    public override void OnNetworkSpawn()
    {
        if (IsServer)
        {
            CurrentHealth.Value = MaxHealth;
        }
    }

    private void Update()
    {
        if (!IsServer) return;

        if (_isInvincible)
        {
            _invincibleTimer -= Time.deltaTime;
            if (_invincibleTimer <= 0) _isInvincible = false;
        }
    }

    [ServerRpc(RequireOwnership = false)]
    public void TakeDamageServerRpc(int damage, Vector2 knockbackDirection, ulong attackerId)
    {
        if (_isDead || _isInvincible) return;
        Debug.Log($"{OwnerClientId} took {damage} damage from {attackerId}");

        CurrentHealth.Value = Mathf.Clamp(CurrentHealth.Value - damage, 0, MaxHealth);
        _isInvincible = true;
        _invincibleTimer = InvincibilityDuration;

        ApplyKnockbackClientRpc(knockbackDirection);
        FlashSpriteClientRpc();

        // Handle health states
        if (CurrentHealth.Value <= 0)
        {
            CleanUpNetworkEffects();
            _isDead = true;
            PlayDeathAnimationClientRpc();
            DisablePlayerClientRpc(attackerId);

            if (attackerId != OwnerClientId)
            {
                // Get the attacker's PlayerStats
                if (NetworkManager.Singleton.SpawnManager.GetPlayerNetworkObject(attackerId)?.TryGetComponent<PlayerStats>(out var attackerStats) == true)
                {
                    attackerStats.RegisterKillServerRpc(OwnerClientId);
                }
            }

            StartCoroutine(ServerRespawnCoroutine());
        }
    }

    [ClientRpc]
    public void ApplyKnockbackClientRpc(Vector2 knockbackDirection) 
    {
        if (_rb != null)
        {
            knockbackDirection.Normalize();
            _rb.linearVelocity = Vector2.zero;
            _rb.AddForce(knockbackDirection * KnockbackForce, ForceMode2D.Impulse);
        }
    }

    [ClientRpc]
    private void PlayDeathAnimationClientRpc()
    {
        if (_netAnimator != null) _netAnimator.SetTrigger("Die");
        if (IsOwner && MusicManager.Instance != null)
        {
            MusicManager.Instance.PlayLocalSoundEffect(SoundEffectType.Death, transform.position);
        }
    }

    [ClientRpc]
    private void DisablePlayerClientRpc(ulong killerId)
    {
        if (_playerMovement != null) _playerMovement.enabled = false;
        GetComponent<PlayerCombat>().enabled = false;

        StartCoroutine(DisableAfterDeathAnim());

        if (IsOwner)
        {
            UIManager.Instance.ShowDeathPanel();
        }
    }

    private IEnumerator DisableAfterDeathAnim()
    {
        float deathAnimDuration = 1.2f;
        if (_flashOverlay != null)
        {
            Destroy(_flashOverlay);
            _flashOverlay = null;
        }
        if (_flashCoroutine != null)
        {
            StopCoroutine(_flashCoroutine);
            _flashCoroutine = null;
        }
        yield return new WaitForSeconds(deathAnimDuration);

        if (TryGetComponent<Collider2D>(out var col)) col.enabled = false;
        if (_spriteRenderer != null) _spriteRenderer.enabled = false;
    }

    private IEnumerator ServerRespawnCoroutine()
    {
        yield return new WaitForSeconds(5f);
        RespawnPlayerClientRpc();
    }

    private IEnumerator InvincibilityBlinkCoroutine()
    {
        Debug.Log("Blink coroutine started");
        float timer = 0f;

        while (timer < blinkDuration)
        {
            // TOGGLE VISIBILITY INSTEAD OF CHANGING ALPHA
            _spriteRenderer.enabled = false;
            yield return new WaitForSeconds(blinkInterval / 2f);

            _spriteRenderer.enabled = true;
            yield return new WaitForSeconds(blinkInterval / 2f);

            timer += blinkInterval;
        }

        // ENSURE SPRITE IS VISIBLE AT END
        _spriteRenderer.enabled = true;
        _blinkCoroutine = null;
    }

    [ClientRpc]
    private void RespawnPlayerClientRpc()
    {
        Debug.Log($"RespawnPlayerClientRpc called for {OwnerClientId}");

        _isDead = false;

        if (TryGetComponent<Collider2D>(out var col)) col.enabled = true;
        if (_spriteRenderer != null)
        {
            _spriteRenderer.enabled = true;
            _spriteRenderer.color = Color.white;
        }

        transform.position = Vector3.zero;

        if (_netAnimator != null)
        {
            _netAnimator.ResetTrigger("Die");
            _netAnimator.SetTrigger("Respawn");
        }

        if (_blinkCoroutine != null)
        {
            StopCoroutine(_blinkCoroutine);
        }
        _blinkCoroutine = StartCoroutine(InvincibilityBlinkCoroutine());

        if (IsServer)
        {
            CurrentHealth.Value = MaxHealth;
            _isInvincible = true;
            _invincibleTimer = blinkDuration;
        }

        if (IsOwner)
        {
            Debug.Log($"Enabling movement for {OwnerClientId}");
            if (_playerMovement != null) _playerMovement.enabled = true;
            if (TryGetComponent<PlayerCombat>(out var combat)) combat.enabled = true;
        }
    }

    [ClientRpc]
    private void FlashSpriteClientRpc()
    {
        Debug.Log($"Flash RPC received on client {NetworkManager.LocalClientId}");
        if (_spriteRenderer != null && _spriteRenderer.enabled)
        {
            Debug.Log("Starting flash coroutine");
            if (_flashCoroutine != null)
            {
                StopCoroutine(_flashCoroutine);
            }
            _flashCoroutine = StartCoroutine(FlashCoroutine());
        } else
        {
            Debug.LogError("SpriteRenderer is null!");
        }
    }

    private IEnumerator FlashCoroutine()
    {
        Debug.Log("Flash coroutine started");

        if (_flashOverlay != null)
        {
            Destroy(_flashOverlay);
            _flashOverlay = null;
        }

        // Create flash overlay object
        _flashOverlay = new GameObject("FlashOverlay");
        _flashOverlay.transform.SetParent(transform);
        _flashOverlay.transform.localPosition = Vector3.zero;
        _flashOverlay.transform.localRotation = Quaternion.identity;
        _flashOverlay.transform.localScale = Vector3.one;

        // Add renderer
        SpriteRenderer flashRenderer = _flashOverlay.AddComponent<SpriteRenderer>();
        flashRenderer.sprite = _spriteRenderer.sprite;
        flashRenderer.color = flashColor;
        flashRenderer.sortingOrder = _spriteRenderer.sortingOrder + 1;

        // Fade out flash
        float elapsed = 0f;
        while (elapsed < flashDuration)
        {
            if (flashRenderer == null || _spriteRenderer == null)
                break;

            // Update to match current animation frame
            flashRenderer.sprite = _spriteRenderer.sprite;

            // Fade out alpha
            float alpha = Mathf.Lerp(1f, 0f, elapsed / flashDuration);
            flashRenderer.color = new Color(flashColor.r, flashColor.g, flashColor.b, alpha);

            elapsed += Time.deltaTime;
            yield return null;
        }

        // Critical fix: Unparent before destruction to prevent dangling references
        if (_flashOverlay != null)
        {
            _flashOverlay.transform.SetParent(null);
            Destroy(_flashOverlay);
            _flashOverlay = null;
        }

        _flashCoroutine = null;
    }

    private void CleanUpNetworkEffects()
    {
        if (_flashOverlay != null)
        {
            Destroy(_flashOverlay);
            _flashOverlay = null;
        }

        // Stop all coroutines when player dies
        if (_flashCoroutine != null) StopCoroutine(_flashCoroutine);
        if (_blinkCoroutine != null) StopCoroutine(_blinkCoroutine);
    }
}