using UnityEngine;

public class WindSlashProjectile : MonoBehaviour
{
    [Header("Settings")]
    public float speed = 15f;
    public float lifetime = 3f;
    public float damage = 20;

    private Vector2 _direction;
    private Rigidbody2D _rb;
    private SpriteRenderer _spriteRenderer;

    private void Awake()
    {
        // Get components safely
        _rb = GetComponent<Rigidbody2D>();
        _spriteRenderer = GetComponent<SpriteRenderer>();

        if (_rb == null)
        {
            Debug.LogError("Rigidbody2D missing on WindSlashProjectile!", this);
            enabled = false; // Disable script if critical component is missing
            return;
        }

        Destroy(gameObject, lifetime);
    }

    public void SetDirection(bool facingRight)
    {
        if (_rb == null) return; // Safety check

        _direction = facingRight ? Vector2.right : Vector2.left;
        _rb.linearVelocity = _direction * speed;

        // Flip sprite if needed
        if (_spriteRenderer != null)
        {
            _spriteRenderer.flipX = !facingRight;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        //if (other.CompareTag("Enemy"))
        //{
        //    var enemyHealth = other.GetComponent<Health>();
        //    if (enemyHealth != null)
        //    {
        //        enemyHealth.TakeDamage(damage);
        //    }
        //    Destroy(gameObject);
        //}
        //else if (!other.isTrigger && !other.CompareTag("Player"))
        //{
        //    Destroy(gameObject);
        //}
    }
}