using Unity.Netcode;
using UnityEngine;

public class DamageHitbox : NetworkBehaviour
{
    [Header("Damage Settings")]
    public int Damage = 10;
    public Vector2 KnockbackDirection = Vector2.right;
    public float KnockbackMultiplier = 1f;

    private ulong _ownerId;
    private PlayerMovement _ownerMovement;

    private void Start()
    {
        // Find player network object in hierarchy
        Transform parent = transform;
        while (parent != null)
        {
            NetworkObject netObj = parent.GetComponent<NetworkObject>();
            if (netObj != null)
            {
                _ownerId = netObj.OwnerClientId;
                _ownerMovement = parent.GetComponent<PlayerMovement>();
                return;
            }
            parent = parent.parent;
        }

        Debug.LogError("Player NetworkObject not found in hierarchy!");
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Only server processes damage
        if (!NetworkManager.Singleton.IsServer) return;
        if (other.isTrigger) return;
        if (GameManager.Instance == null || !GameManager.Instance.gameStarted.Value) return;

        if (other.TryGetComponent<PlayerHealth>(out var health))
        {
            // Don't damage self
            if (health.OwnerClientId == _ownerId) return;

            Vector2 attackerPos = transform.position;
            Vector2 victimPos = other.transform.position;
            Vector2 knockbackDir = (victimPos - attackerPos).normalized;

            health.TakeDamageServerRpc(
                Damage,
                knockbackDir,
                _ownerId
            );

            Debug.Log($"Damage dealt by {_ownerId} to {health.OwnerClientId} | Dir: {knockbackDir}");
        }
    }
}