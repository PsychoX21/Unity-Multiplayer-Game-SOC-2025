using Unity.Netcode;
using Unity.Collections;
using UnityEngine;
using System.Collections;

public class PlayerStats : NetworkBehaviour
{
    public NetworkVariable<int> Kills = new(0);
    public NetworkVariable<int> Deaths = new(0);
    public NetworkVariable<FixedString64Bytes> playerName = new("Player",
        NetworkVariableReadPermission.Everyone,
        NetworkVariableWritePermission.Server);

    public override void OnNetworkSpawn()
    {
        if (IsOwner)
        {
            string name = PlayerPrefsManager.GetPlayerName();
            SetPlayerNameServerRpc(name);
        }
    }

    [ServerRpc(RequireOwnership = false)]
    private void SetPlayerNameServerRpc(string name)
    {
        playerName.Value = name;
    }

    [ClientRpc]
    private void UpdateLeaderboardsClientRpc()
    {
        UIManager.Instance.UpdateLeaderboard(UIManager.Instance.pauseLeaderboardContent);
        UIManager.Instance.UpdateLeaderboard(UIManager.Instance.gameOverLeaderboardContent);
    }

    [ServerRpc(RequireOwnership = false)]
    public void RegisterKillServerRpc(ulong victimId)
    {
        Kills.Value++;
        if (MusicManager.Instance != null) MusicManager.Instance.PlaySoundEffect(SoundEffectType.Kill, transform.position);

        if (NetworkManager.Singleton.SpawnManager.GetPlayerNetworkObject(victimId)
            .TryGetComponent<PlayerStats>(out var victimStats))
        {
            victimStats.Deaths.Value++;

            NotifyKillfeedClientRpc(
                playerName.Value.ToString(),
                victimStats.playerName.Value.ToString(),
                NetworkObject.OwnerClientId,
                victimId
            );
        }

        UpdateLeaderboardsClientRpc();
    }

    [ClientRpc]
    private void NotifyKillfeedClientRpc(string killername, string victimname, ulong killerId, ulong victimId)
    {
        UIManager.Instance.AddKillfeed(killername, victimname, killerId, victimId);
    }

    public override void OnNetworkDespawn()
    {
        // Only update on server
        if (IsServer)
        {
            if (GameManager.Instance != null && GameManager.Instance.gameEnded.Value) return;

            Debug.Log($"PlayerStats despawned - updating leaderboards");
            StartCoroutine(DelayedLeaderboardUpdate());
        }
        base.OnNetworkDespawn();
    }

    private IEnumerator DelayedLeaderboardUpdate()
    {
        // Wait for despawn to propagate
        yield return new WaitForSeconds(0.1f);

        UIManager.Instance?.UpdateLeaderboard(UIManager.Instance.pauseLeaderboardContent);
        UIManager.Instance?.UpdateLeaderboard(UIManager.Instance.gameOverLeaderboardContent);
    }
}