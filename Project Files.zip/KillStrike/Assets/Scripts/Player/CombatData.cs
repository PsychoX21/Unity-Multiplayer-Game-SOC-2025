using UnityEngine;

[CreateAssetMenu(fileName = "CombatData", menuName = "Player/CombatData")]
public class CombatData : ScriptableObject
{
    [Header("Punch")]
    public float punchDamage = 15f;
    public float punchDuration = 0.3f;
    public float punchCooldown = 0.5f;
    public Vector2 punchKnockback = new Vector2(5f, 2f);

    [Header("Kick")]
    public float kickDamage = 20f;
    public float kickDuration = 0.4f;
    public float kickCooldown = 0.6f;
    public Vector2 kickKnockback = new Vector2(7f, 3f);

    [Header("Dropkick")]
    public float dropKickDamage = 25f;
    public float dropKickDuration = 0.8f;
    public float dropKickCooldown = 1f;
    public float dropKickForce = 10f;
    public float dropKickGravityScale = 3f;
    public Vector2 dropKickKnockback = new Vector2(10f, 5f);

    [Header("Sword")]
    public float swordDamage = 30f;
    public float swordDuration = 0.4f;
    public float swordCooldown = 0.6f;
    public Vector2 swordKnockback = new Vector2(8f, 4f);

    [Header("Air Sword")]
    public float swordAirDamage = 25f;
    public float swordAirDuration = 0.5f;
    public float swordAirCooldown = 0.7f;
    public float swordAirDownForce = 3f;
    public Vector2 swordAirKnockback = new Vector2(6f, 8f);

    [Header("Wind Slash")]
    public float windSlashDamage = 40f;
    public float windSlashChargeRequired = 3f;
    public float windSlashCooldown = 1.5f;
}