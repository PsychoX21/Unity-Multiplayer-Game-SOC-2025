using UnityEngine;
using Unity.Netcode;
using Unity.Cinemachine;
using System.Collections;
using TMPro;
using UnityEngine.SceneManagement;

public class PlayerNetwork : NetworkBehaviour
{
    private PlayerMovement playerMovement;
    private PlayerCombat playerCombat;
    private CinemachineCamera virtualCamera;
    [SerializeField] private GameObject[] combatHitboxes;

    public override void OnNetworkSpawn()
    {
        base.OnNetworkSpawn();

        playerMovement = GetComponent<PlayerMovement>();
        playerCombat = GetComponent<PlayerCombat>();

        playerCombat.enabled = true;

        if (IsOwner)
        {
            playerMovement.enabled = true;
            StartCoroutine(AssignCameraWhenReady());
        }
        else
        {
            playerMovement.enabled = false;
            foreach (var hitbox in combatHitboxes)
            {
                hitbox.SetActive(false);
            }
        }

        StartCoroutine(CheckGameManagerReady());

        if (IsOwner && GameManager.Instance != null && GameManager.Instance.gameStarted.Value)
        {
            StartCoroutine(EnableForLateJoiner());
        }
    }

    private IEnumerator EnableForLateJoiner()
    {
        // Wait for camera assignment
        while (CameraReference.Instance == null)
        {
            yield return null;
        }

        // Enable movement immediately for late joiners
        playerMovement.enabled = true;
        playerCombat.enabled = true;

        // Show fight UI
        if (GameManager.Instance.countdownText != null)
        {
            GameManager.Instance.countdownText.text = "FIGHT!";
            StartCoroutine(HideTextAfterDelay(2f));
        }
    }

    private IEnumerator HideTextAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        if (GameManager.Instance.countdownText != null)
            GameManager.Instance.countdownText.gameObject.SetActive(false);
    }

    private IEnumerator CheckGameManagerReady()
    {
        while (GameManager.Instance == null)
        {
            yield return null;
        }

        // Add UI sync for client
        if (IsOwner)
        {
            // Wait extra frame to ensure UI is ready
            yield return null;

            if (GameManager.Instance.countdownText == null)
            {
                var textObj = GameObject.FindGameObjectWithTag("CountdownText");
                if (textObj) GameManager.Instance.countdownText = textObj.GetComponent<TextMeshProUGUI>();
            }

            // Force UI update
            if (GameManager.Instance.gameStarted.Value &&
                GameManager.Instance.countdownText != null)
            {
                GameManager.Instance.countdownText.text = "FIGHT!";
            }
        }

        // If game already started, enable combat immediately
        if (GameManager.Instance.gameStarted.Value && IsOwner)
        {
            playerCombat.enabled = true;
            playerMovement.enabled = true;
        }
    }

    private IEnumerator AssignCameraWhenReady()
    {
        while (CameraReference.Instance == null)
        {
            yield return null;
        }

        CameraReference.Instance.Follow = transform;
        CameraReference.Instance.LookAt = transform;
    }

    public override void OnNetworkDespawn()
    {
        base.OnNetworkDespawn();

        if (IsOwner && virtualCamera != null)
        {
            virtualCamera.Follow = null;
            virtualCamera.LookAt = null;
        }
    }
}