using UnityEngine;
using UnityEngine.Scripting.APIUpdating;
using System.Collections;
using System.Data;

public class Player : MonoBehaviour
{
    #region Components
    private Rigidbody2D rb;
    private Animator anim;
    private BoxCollider2D col;
    private Vector2 moveInput;
    #endregion

    #region Constants
    // Movement
    public const float walkSpeed = 30f;
    public const float maxRunSpeed = 45f;
    public const float runAcceleration = 250f;
    public const float runDeceleration = 100f;
    public const float airAccelMult = 0.65f;
    public const float airDecelMult = 0.5f;

    // Jump
    public const float jumpSpeed = 75f;
    public const float jumpHBoost = 20f;
    public const float jumpTime = 0.5f;
    public const float jumpBuffer = 0.2f;
    public const float jumpCoyoteTime = 0.2f;
    public const int jumpCornerCorrection = 4;

    // Wall
    public const float wallJumpSpeed = 60f;
    public const float wallJumpDistance = 0.5f;
    public const float wallJumpRunLerp = 0.5f;
    public const float wallSlideSpeed = 20f;
    public const float wallSlideTime = 0.3f;
    //public const float wallJumpHSpeed = maxRunSpeed + jumpHBoost;

    // Dash
    public const float dashSpeed = 120f;
    public const float endDashSpeed = 80f;
    public const float dashTime = 0.15f;
    public const float dashSleepTime = 0.3f;
    public const float dashEndRunLerp = 0.5f;
    public const float dashCooldown = 0.4f;
    public const int dashCornerCorrection = 3;
    public const int dashHJumpThruNudge = 3;
    public const int dashVFloorSnapDist = 2;

    // Physics
    public const float maxFall = -90f;
    public const float fastMaxFall = -120f;
    public const float gravity = -450f;
    public const float fastGravity = -600f;
    public const float halfGravityThreshold = 30f;

    // Rebound
    public const float reboundJumpSpeedY = 60f;
    public const float reboundJumpSpeedX = 60f;
    public const float reboundJumpTime = 0.1f;
    //public const float wallBounceJumpHSpeedBoost = 15f;
    //public const float wallBounceJumpVSpeedBoost = -30f;
    #endregion

    #region States
    public enum State
    {
        Normal,
        Jumping,
        Dashing,
        Falling,
        Boosted,
        WallJumping,
        WallSliding,
        SuperJumping,
        Invincible,
        Dead,
        Respawning,
        WalkInRight,
        WalkInLeft
    }
    public State currentState = State.Normal;
    #endregion

    #region Variables
    public Vector2 velocity;
    public bool isFacingRight = true;
    public bool isGrounded;
    public bool canDash = true;
    public float dashCooldownTimer;
    public float wallSlideTimer;
    public float jumpBufferTimer;
    public float coyoteTimer;
    public float gravityScale;
    public bool justRespawned = false;
    #endregion

    #region Setup
    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        col = GetComponent<BoxCollider2D>();
        anim = GetComponent<Animator>();

        // Physics setup
        rb.gravityScale = 0;
        rb.mass = 1;
        rb.angularDamping = 0;
    }

    void Start()
    {
        isFacingRight = false;
        gravityScale = gravity;
    }
    #endregion

    #region Main Loop
    void Update()
    {
        HandleInput();
        UpdateTimers();
        StateHandler();
        HandleJump();
        HandleJumpCut();
        HandleWallJump();
    }

    private void FixedUpdate()
    {
        CheckCollisions();
        HandleMovement();
        HandleGravity();
        HandleNudges();

        rb.linearVelocity = velocity;
    }
    #endregion

    #region Input Handling
    private void HandleInput()
    {
        if (UserInput.instance.controls.Jumping.Jump.WasPressedThisFrame())
        {
            jumpBufferTimer = jumpBuffer;
        }

        if (UserInput.instance.controls.Dashing.Dash.WasPressedThisFrame() && canDash)
        {
            StartCoroutine(DashSequence());
        }
    }
    #endregion

    #region Core Movement
    private void HandleMovement()
    {
        float targetSpeed = GetTargetSpeed();
        float acceleration = CalculateAcceleration(targetSpeed);

        velocity.x = Mathf.MoveTowards(
            velocity.x, 
            targetSpeed, 
            acceleration * Time.fixedDeltaTime
        );
    }

    private float GetTargetSpeed()
    {
        float baseSpeed = UserInput.instance.controls.Walking.Walk.IsPressed() ? walkSpeed : maxRunSpeed;
        return UserInput.instance.moveInput.x * baseSpeed;
    }

    private float CalculateAcceleration(float targetSpeed)
    {
        bool isAccelerating = Mathf.Abs(targetSpeed) > 0.01f;
        if (isGrounded)
        {
            return isAccelerating ? runAcceleration : runDeceleration;
        }
        return isAccelerating ? runAcceleration * airAccelMult : runDeceleration * airDecelMult;
    }
    #endregion

    #region Jump System
    private void HandleJump()
    {
        // Only allow jumping in these states
        if (currentState == State.Normal ||
            currentState == State.WallSliding)
        {
            if (jumpBufferTimer > 0 && coyoteTimer > 0)
            {
                velocity.y = jumpSpeed;
                velocity.x += UserInput.instance.moveInput.x * jumpHBoost;
                jumpBufferTimer = 0;
                coyoteTimer = 0;
                currentState = State.Jumping;
            }
        }
    }

    private void HandleJumpCut()
    {
        if (currentState != State.Jumping) return;
        if (UserInput.instance.controls.Jumping.Jump.WasReleasedThisFrame() && velocity.y < 0)
            velocity.y *= 0.5f;
    }
    #endregion

    #region Wall System
    private void HandleWallSlide()
    {
        if (CheckWall() && !isGrounded && velocity.y < 0)
        {
            wallSlideTimer += Time.deltaTime;
            if (wallSlideTimer >= wallSlideTime)
            {
                currentState = State.WallSliding;
                velocity.y = Mathf.Max(velocity.y, -wallSlideSpeed);
            }
        }
        else
        {
            wallSlideTimer = 0;
            if (currentState == State.WallSliding)
                currentState = State.Normal;
        }
    }

    private void HandleWallJump()
    {
        if (currentState == State.WallSliding && UserInput.instance.controls.Jumping.Jump.WasPressedThisFrame())
        {
            velocity = new Vector2(
                (isFacingRight ? -1 : 1) * (maxRunSpeed + jumpHBoost),
                wallJumpSpeed
            );
            StartCoroutine(WallJumpControlRegain());
            currentState = State.WallJumping;
        }
    }

    IEnumerator WallJumpControlRegain()
    {
        float timer = 0;
        while (timer < wallJumpRunLerp)
        {
            velocity.x = Mathf.Lerp(
                velocity.x,
                UserInput.instance.moveInput.x * maxRunSpeed,
                timer / wallJumpRunLerp
            );
            timer += Time.deltaTime;
            yield return null;
        }
    }
    #endregion

    #region Dash System
    private IEnumerator DashSequence()
    {
        currentState = State.Dashing;
        canDash = false;
        dashCooldownTimer = dashCooldown;

        Vector2 dashDir = GetDashDirection();
        velocity = dashDir * dashSpeed;

        float dashTimer = dashTime;
        while (dashTimer > 0)
        {
            dashTimer -= Time.deltaTime;
            HandleDashNudges(dashDir);
            yield return null;
        }

        velocity = Vector2.ClampMagnitude(velocity, endDashSpeed);
        yield return new WaitForSeconds(dashSleepTime);

        float lerpTimer = 0;
        while (lerpTimer < dashEndRunLerp)
        {
            velocity.x = Mathf.Lerp(
                velocity.x,
                UserInput.instance.moveInput.x * maxRunSpeed,
                lerpTimer / dashEndRunLerp
            );
            lerpTimer += Time.deltaTime;
            yield return null;
        }

        currentState = State.Normal;
    }

    private Vector2 GetDashDirection()
    {
        Vector2 input = new Vector2(
            UserInput.instance.moveInput.x,
            UserInput.instance.moveInput.y
        );
        return input != Vector2.zero ? input.normalized : (isFacingRight ? Vector2.right : Vector2.left);
    }

    private void HandleDashNudges(Vector2 dir)
    {
        // Horizontal nudge
        Vector2 hNudge = dir * dashCornerCorrection;
        if (!Physics2D.Raycast(rb.position, hNudge.normalized, dashCornerCorrection))
            rb.position += hNudge * Time.deltaTime;

        // Vertical snap
        RaycastHit2D groundCheck = Physics2D.Raycast(
            rb.position,
            Vector2.down,
            dashVFloorSnapDist
        );
        if (groundCheck.collider != null)
            velocity.y = 0;
    }
    #endregion

    #region Physics
    private void HandleGravity()
    {
        if (currentState == State.Dashing) return;

        gravityScale = UserInput.instance.moveInput.y < -0.1f ? fastGravity : gravity;
        gravityScale = Mathf.Abs(velocity.y) < halfGravityThreshold ? gravity * 0.5f : gravityScale;

        velocity.y += gravityScale * Time.fixedDeltaTime;
        if (isGrounded && velocity.y < 0)
            velocity.y = 0f; // Reset vertical velocity on ground contact

        if (UserInput.instance.moveInput.y < -0.1f)
            velocity.y = Mathf.Clamp(velocity.y, 0f, fastMaxFall);
        else
            velocity.y = Mathf.Max(velocity.y, maxFall);
    }

    private void CheckCollisions()
    {
        // Ground check
        RaycastHit2D groundHit = Physics2D.BoxCast(
            col.bounds.center,
            col.bounds.size,
            0f,
            Vector2.down,
            0.2f
        );
        isGrounded = groundHit.collider != null;

        // Coyote time
        coyoteTimer = isGrounded ? jumpCoyoteTime : coyoteTimer - Time.fixedDeltaTime;

        // Wall check
        if (CheckWall() && !isGrounded)
            HandleWallSlide();
    }

    private bool CheckWall()
    {
        Vector2 direction = isFacingRight ? Vector2.right : Vector2.left;
        return Physics2D.BoxCast(
            col.bounds.center,
            col.bounds.size,
            0f,
            direction,
            wallJumpDistance
        ).collider != null;
    }
    #endregion

    #region Helpers
    private void HandleNudges()
    {
        if (currentState == State.Jumping)
        {
            Vector2 nudge = new Vector2(
                UserInput.instance.moveInput.x * jumpCornerCorrection,
                0
            );
            if (!Physics2D.Raycast(rb.position, nudge.normalized, jumpCornerCorrection))
                rb.position += nudge * Time.fixedDeltaTime;
        }
    }

    private void UpdateTimers()
    {
        if (currentState == State.Jumping || currentState == State.WallJumping)
        {
            jumpBufferTimer = 0;
        }
        else
        {
            jumpBufferTimer -= Time.deltaTime;
        }
        dashCooldownTimer -= Time.deltaTime;
        if (dashCooldownTimer <= 0) canDash = true;
    }

    private void StateHandler()
    {
        if (currentState == State.Dashing) return;
        if (isGrounded) currentState = State.Normal;
        if (velocity.y > 0) currentState = State.Jumping;
        if (velocity.y < 0 && !isGrounded) currentState = State.Falling;
    }
    #endregion
}