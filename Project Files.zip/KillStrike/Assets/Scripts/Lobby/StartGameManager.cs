using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using Unity.Networking.Transport.Relay;
using Unity.Services.Relay;
using Unity.Services.Relay.Models;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartGameManager : MonoBehaviour
{
    private bool hasTriedJoinRelay = false;

    private void Start()
    {
        LobbyManager.Instance.OnLobbyStartGame += LobbyManager_OnLobbyStartGame;
    }

    private void LobbyManager_OnLobbyStartGame(object sender, LobbyManager.LobbyEventArgs e)
    {
        // Start Game!
        if (LobbyManager.IsHost)
        {
            CreateRelay();
        }
        else
        {
            JoinRelay(LobbyManager.RelayJoinCode);
        }
    }

    public void StartHost()
    {
        NetworkManager.Singleton.StartHost();
    }

    public void StartClient()
    {
        NetworkManager.Singleton.StartClient();
    }

    private async void CreateRelay()
    {
        try
        {
            Allocation allocation = await RelayService.Instance.CreateAllocationAsync(3);

            string joinCode = await RelayService.Instance.GetJoinCodeAsync(allocation.AllocationId);
            Debug.Log("Allocated Relay JoinCode: " + joinCode);

            RelayServerData relayServerData = allocation.ToRelayServerData("dtls");

            NetworkManager.Singleton.GetComponent<UnityTransport>().SetRelayServerData(relayServerData);

            LobbyManager.Instance.SetRelayJoinCode(joinCode);

            bool success = NetworkManager.Singleton.StartHost();
            if (!success)
            {
                Debug.LogError("Failed to start host.");
                return;
            }

            NetworkManager.Singleton.SceneManager.LoadScene("GameWorld", LoadSceneMode.Single);
        }
        catch (RelayServiceException e)
        {
            Debug.LogError("CreateRelay failed: " + e);
        }
    }

    private async void JoinRelay(string joinCode)
    {
        if (hasTriedJoinRelay)
        {
            Debug.Log("Already attempted to join Relay, skipping.");
            return;
        }

        // Skip only if already connected (not if StartClient was just called before and failed)
        if (NetworkManager.Singleton.IsClient && NetworkManager.Singleton.IsConnectedClient)
        {
            Debug.LogWarning("Client already connected, skipping JoinRelay.");
            return;
        }

        hasTriedJoinRelay = true;

        try
        {
            Debug.Log("Attempting to join Relay with code: " + joinCode);
            JoinAllocation joinAllocation = await RelayService.Instance.JoinAllocationAsync(joinCode);

            RelayServerData relayServerData = joinAllocation.ToRelayServerData("dtls");

            NetworkManager.Singleton.GetComponent<UnityTransport>().SetRelayServerData(relayServerData);

            //SceneManager.LoadScene("GameWorld");

            //// Delay StartClient slightly to allow the scene to load
            //await System.Threading.Tasks.Task.Delay(200); // Optional but recommended

            NetworkManager.Singleton.StartClient();

            Debug.Log("Started client after joining relay.");
        }
        catch (RelayServiceException e)
        {
            Debug.LogError("JoinRelay failed: " + e);
        }
    }
}
