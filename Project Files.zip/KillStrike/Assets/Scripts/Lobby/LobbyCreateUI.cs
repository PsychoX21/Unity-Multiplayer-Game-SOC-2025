using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class LobbyCreateUI : MonoBehaviour {


    public static LobbyCreateUI Instance { get; private set; }


    [SerializeField] private Button createButton;
    [SerializeField] private Button joinLobbyButton;
    [SerializeField] private Button lobbyNameButton;
    [SerializeField] private Button publicPrivateButton;
    [SerializeField] private Button maxPlayersButton;
    [SerializeField] private Button gameModeButton;
    [SerializeField] private TextMeshProUGUI lobbyNameText;
    [SerializeField] private TextMeshProUGUI publicPrivateText;
    [SerializeField] private TextMeshProUGUI maxPlayersText;
    [SerializeField] private TextMeshProUGUI gameModeText;
    [SerializeField] private TextMeshProUGUI createButtonText;
    [SerializeField] private RectTransform layoutGroupContainer;


    private string lobbyName;
    private bool isPrivate;
    private int maxPlayers;
    private LobbyManager.GameMode gameMode;

    private bool isCreating = false;

    private void Awake() {
        Instance = this;

        createButton.onClick.AddListener(async () => {
            if (isCreating) return;
            isCreating = true;

            createButtonText.text = "Creating...";
            SetUIInteractable(false);

            try
            {
                await LobbyManager.Instance.CreateLobby(
                    lobbyName,
                    maxPlayers,
                    isPrivate,
                    gameMode
                );
            } catch (System.Exception e) {
                Debug.LogError($"Lobby creation failed: {e.Message}");
                ResetCreateButton();
            }
        });

        lobbyNameButton.onClick.AddListener(() => {
            UI_InputWindow.Show_Static("Lobby Name", lobbyName, "abcdefghijklmnopqrstuvxywzABCDEFGHIJKLMNOPQRSTUVXYWZ .,-", 20,
            () => {
                // Cancel
            },
            (string lobbyName) => {
                this.lobbyName = lobbyName;
                UpdateText();
            });
        });

        publicPrivateButton.onClick.AddListener(() => {
            isPrivate = !isPrivate;
            UpdateText();
        });

        maxPlayersButton.onClick.AddListener(() => {
            UI_InputWindow.Show_Static("Max Players", maxPlayers,
            () => {
                // Cancel
            },
            (int maxPlayers) => {
                this.maxPlayers = maxPlayers;
                UpdateText();
            });
        });

        joinLobbyButton.onClick.AddListener(() => {
            Hide();
            LobbyListUI.Instance.Show();
        });

        //gameModeButton.onClick.AddListener(() => {
        //    switch (gameMode) {
        //        default:
        //        case LobbyManager.GameMode.FreeForAll:
        //            gameMode = LobbyManager.GameMode.TeamDeathmatch;
        //            break;
        //        case LobbyManager.GameMode.TeamDeathmatch:
        //            gameMode = LobbyManager.GameMode.FreeForAll;
        //            break;
        //    }
        //    UpdateText();
        //});

        Hide();
    }

    private void SetUIInteractable(bool interactable)
    {
        lobbyNameButton.interactable = interactable;
        publicPrivateButton.interactable = interactable;
        maxPlayersButton.interactable = interactable;
        gameModeButton.interactable = interactable;
        joinLobbyButton.interactable = interactable;
        createButton.interactable = interactable;
    }

    private void ResetCreateButton()
    {
        isCreating = false;
        createButtonText.text = "Create";
        SetUIInteractable(true);
    }

    private void UpdateText() {
        lobbyNameText.text = lobbyName;
        publicPrivateText.text = isPrivate ? "Private" : "Public";
        maxPlayersText.text = maxPlayers.ToString();
        gameModeText.text = gameMode.ToString();

        LayoutRebuilder.ForceRebuildLayoutImmediate(layoutGroupContainer);
    }

    private void Hide() {
        gameObject.SetActive(false);
    }

    public void Show() {
        gameObject.SetActive(true);

        lobbyName = "MyLobby";
        isPrivate = false;
        maxPlayers = 2;
        gameMode = LobbyManager.GameMode.FreeForAll;

        UpdateText();
    }

    public void OnLobbyCreated()
    {
        ResetCreateButton();
        Hide();
    }
}