using Unity.Netcode;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneCleaner : MonoBehaviour
{
    private void Start()
    {
        if (SceneManager.GetActiveScene().name == "MainMenu")
        {
            CleanUpManagersOnly();
        }
    }

    private void CleanUpManagersOnly()
    {
        Debug.Log("[SceneCleaner] Cleaning up managers only");

        // Clean in reverse dependency order
        CleanUIManager();
        CleanNetworkManager();
        CleanGameManager();
        CleanMusicManager();
    }

    private void CleanUIManager()
    {
        var uiManager = FindFirstObjectByType<UIManager>();
        if (uiManager != null)
        {
            Debug.Log($"Destroying UIManager ({uiManager.gameObject.name})");
            Destroy(uiManager.gameObject);
        }
    }

    private void CleanNetworkManager()
    {
        // Try both methods of finding NetworkManager
        NetworkManager netManager = NetworkManager.Singleton;
        if (netManager == null) netManager = FindFirstObjectByType<NetworkManager>();

        if (netManager != null)
        {
            Debug.Log($"Destroying NetworkManager ({netManager.gameObject.name})");
            if (netManager.IsListening) netManager.Shutdown();
            Destroy(netManager.gameObject);
        }
    }

    private void CleanGameManager()
    {
        // Use singleton instance directly
        if (GameManager.Instance != null)
        {
            Debug.Log($"Destroying GameManager ({GameManager.Instance.gameObject.name})");
            Destroy(GameManager.Instance.gameObject);
            // Let OnDestroy handle nullifying the instance
        }
    }

    private void CleanMusicManager()
    {
        if (MusicManager.Instance != null)
        {
            Debug.Log($"Destroying MusicManager ({MusicManager.Instance.gameObject.name})");
            Destroy(MusicManager.Instance.gameObject);
        }
    }
}