using UnityEngine;
using UnityEngine.Audio;

public class AudioManager : MonoBehaviour
{
    public AudioSource musicSource;
    public AudioSource sfxSource;

    public AudioClip backgroundMusic;
    public AudioClip buttonClickSFX;
    public AudioClip playButtonSFX;

    void Start()
    {
        PlayMusic();
    }

    public void PlayMusic()
    {
        if (musicSource && backgroundMusic)
        {
            musicSource.clip = backgroundMusic;
            musicSource.loop = true;
            musicSource.Play();
        }
    }

    public void PlayButtonClick()
    {
        if (sfxSource && buttonClickSFX)
        {
            sfxSource.PlayOneShot(buttonClickSFX);
        }
    }

    public void PlayPlayButtonClick()
    {
        if (sfxSource && playButtonSFX)
        {
            sfxSource.PlayOneShot(playButtonSFX);
        }
    }
}
