using UnityEngine;
using UnityEngine.EventSystems;

public class PanelTracker : MonoBehaviour
{
    [SerializeField] private string panelName;
    [SerializeField] private GameObject defaultSelected;

    private void Start()
    {
        if (!string.IsNullOrEmpty(panelName) && defaultSelected != null)
        {
            SelectedObjectManager.Instance.SetPanelDefault(panelName, defaultSelected);
        }
    }

    private void OnEnable()
    {
        if (!string.IsNullOrEmpty(panelName))
        {
            SelectedObjectManager.Instance.RestorePanelSelection(panelName);
        }
    }

    private void Update()
    {
        GameObject selected = EventSystem.current.currentSelectedGameObject;
        if (selected != null && selected.transform.IsChildOf(transform))
        {
            SelectedObjectManager.Instance.UpdateSelectedForPanel(panelName, selected);
        }
    }
}