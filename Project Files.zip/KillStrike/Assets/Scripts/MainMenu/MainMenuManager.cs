using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
using System.Collections;
using TMPro;

public class MainMenuManager : MonoBehaviour
{
    public GameObject exitConfirmPanel;
    public GameObject settingsPanel;

    [Header("First Selected Buttons")]
    public GameObject mainMenuFirstButton;
    public GameObject settingsFirstButton;
    public GameObject exitConfirmFirstButton;

    public TextMeshProUGUI playButtonText;
    private string originalPlayButtonText;

    public AudioManager audioManager;

    public float sceneLoadDelay = 2f;

    private void Start()
    {
        SetSelected(mainMenuFirstButton);

        if (playButtonText != null)
        {
            originalPlayButtonText = playButtonText.text;
        }
    }

    public void PlayGame()
    {
        if (audioManager != null)
        {
            audioManager.PlayPlayButtonClick();
        }
        else
        {
            Debug.LogWarning("AudioManager not assigned to MainMenuManager. Play sound won't work.");
        }

        if (playButtonText != null)
        {
            playButtonText.text = "LOADING...";
        }

        StartCoroutine(LoadSceneAfterDelay("LobbyScene"));
    }

    IEnumerator LoadSceneAfterDelay(string sceneName)
    {
        yield return new WaitForSeconds(sceneLoadDelay);

        if (playButtonText != null)
        {
            playButtonText.text = originalPlayButtonText;
        }

        SceneManager.LoadScene(sceneName);
    }

    public void OpenSettings()
    {
        settingsPanel.SetActive(true);
        SetSelected(settingsFirstButton);
    }

    public void CloseSettings()
    {
        settingsPanel.SetActive(false);
        SetSelected(mainMenuFirstButton);
    }

    public void ExitGame()
    {
        exitConfirmPanel.SetActive(true);
        SetSelected(exitConfirmFirstButton);
    }

    public void ConfirmExit()
    {
        Application.Quit();
    }

    public void CancelExit()
    {
        exitConfirmPanel.SetActive(false);
        SetSelected(mainMenuFirstButton);
    }

    private void SetSelected(GameObject selected)
    {
        EventSystem.current.SetSelectedGameObject(null);
        EventSystem.current.SetSelectedGameObject(selected);
    }
}
