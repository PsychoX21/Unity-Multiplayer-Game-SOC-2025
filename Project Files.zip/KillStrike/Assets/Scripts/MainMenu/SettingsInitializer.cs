using UnityEngine;
using UnityEngine.Audio;

public class SettingsInitializer : MonoBehaviour
{
    [SerializeField] private AudioMixer mixer;
    [SerializeField] private ResolutionSettings resolutionSettings;

    void Start()
    {
        InitializeAudioSettings();
        InitializeResolutionSettings();
    }

    void InitializeAudioSettings()
    {
        if (mixer != null)
        {
            SetMixerVolume("MasterVolume", PlayerPrefsManager.GetMasterVolume());
            SetMixerVolume("MusicVolume", PlayerPrefsManager.GetMusicVolume());
            SetMixerVolume("SFXVolume", PlayerPrefsManager.GetSFXVolume());
        }
    }

    private void SetMixerVolume(string parameter, float value)
    {
        float volume = value > 0 ? Mathf.Log10(value / 20f) * 20f : -80f;
        mixer.SetFloat(parameter, volume);
    }

    void InitializeResolutionSettings()
    {
        var (width, height, fullscreen) = PlayerPrefsManager.GetResolution();
        Screen.SetResolution(width, height, fullscreen);

        if (!PlayerPrefsManager.HasResolution())
        {
            PlayerPrefsManager.SaveResolution(width, height, fullscreen);
        }
    }
}