using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(RectTransform))]
public class ParallaxUI : MonoBehaviour
{
    [Header("Scroll Settings")]
    [Tooltip("Base scroll speed in pixels per second")]
    public float scrollSpeed = 100f;

    [Tooltip("Parallax factor (0-1) - lower values move slower")]
    [Range(0f, 1f)]
    public float parallaxFactor = 1f;

    [Tooltip("Direction of movement")]
    public bool moveLeft = true;

    [Header("References")]
    [Tooltip("Drag both identical image elements here")]
    public RectTransform[] images = new RectTransform[2];

    // Private variables
    private float imageWidth;
    private float canvasWidth;
    private Vector2 initialPosition1;
    private Vector2 initialPosition2;
    private CanvasScaler canvasScaler;

    void Start()
    {
        // Get canvas scaler for reference resolution
        canvasScaler = GetComponentInParent<CanvasScaler>();

        // Get canvas dimensions
        RectTransform canvasRect = GetComponentInParent<Canvas>().GetComponent<RectTransform>();
        canvasWidth = canvasRect.rect.width;

        // Calculate image width
        if (images.Length > 0 && images[0] != null)
        {
            imageWidth = images[0].rect.width;

            // Store initial positions
            initialPosition1 = images[0].anchoredPosition;
            initialPosition2 = images[1].anchoredPosition;

            // Position second image next to first
            PositionSecondImage();
        }
        else
        {
            Debug.LogError("AutoScrollParallax: Please assign image references in the inspector");
            enabled = false;
        }
    }

    void Update()
    {
        // Calculate movement based on parallax factor
        float movement = (moveLeft ? -1 : 1) * scrollSpeed * parallaxFactor * Time.deltaTime;

        // Move both images
        for (int i = 0; i < images.Length; i++)
        {
            images[i].anchoredPosition += new Vector2(movement, 0);
        }

        // Check for repositioning
        CheckReposition();
    }

    private void PositionSecondImage()
    {
        // Position second image based on direction
        if (moveLeft)
        {
            images[1].anchoredPosition = new Vector2(
                images[0].anchoredPosition.x + imageWidth,
                images[0].anchoredPosition.y
            );
        }
        else
        {
            images[1].anchoredPosition = new Vector2(
                images[0].anchoredPosition.x - imageWidth,
                images[0].anchoredPosition.y
            );
        }
    }

    private void CheckReposition()
    {
        // Screen boundaries in anchored position space
        float screenLeft = -canvasWidth / 2f;
        float screenRight = canvasWidth / 2f;

        for (int i = 0; i < images.Length; i++)
        {
            float imageCenter = images[i].anchoredPosition.x;
            float imageLeft = imageCenter - imageWidth / 2f;
            float imageRight = imageCenter + imageWidth / 2f;

            if (moveLeft)
            {
                if (imageRight < screenLeft)
                {
                    // Move to the right of the other image
                    int otherIndex = (i + 1) % 2;
                    images[i].anchoredPosition = new Vector2(
                        images[otherIndex].anchoredPosition.x + imageWidth,
                        images[i].anchoredPosition.y
                    );
                }
            }
            else // Moving right
            {
                if (imageLeft > screenRight)
                {
                    // Move to the left of the other image
                    int otherIndex = (i + 1) % 2;
                    images[i].anchoredPosition = new Vector2(
                        images[otherIndex].anchoredPosition.x - imageWidth,
                        images[i].anchoredPosition.y
                    );
                }
            }
        }
    }

    // Reset positions if needed
    public void ResetPositions()
    {
        images[0].anchoredPosition = initialPosition1;
        images[1].anchoredPosition = initialPosition2;
        PositionSecondImage();
    }
}