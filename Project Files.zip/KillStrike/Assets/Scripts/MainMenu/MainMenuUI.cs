using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class MainMenuUI : MonoBehaviour
{

    [SerializeField] private TextMeshProUGUI playerNameText;
    private string playerName;

    private void Start()
    {
        // Set default name
        if (PlayerPrefsManager.HasPlayerName())
        {
            playerName = PlayerPrefsManager.GetPlayerName();
        }
        else
        {
            playerName = "Player" + Random.Range(1000, 10000);
            PlayerPrefsManager.SavePlayerName(playerName);
        }

        UpdateNameUI();
    }

    private void UpdateNameUI()
    {
        playerNameText.text = playerName;
        LayoutRebuilder.ForceRebuildLayoutImmediate(playerNameText.rectTransform);
    }

    public void OnEditNameButtonPressed()
    {
        UI_InputWindow.Show_Static(
            "Enter Your Name",
            playerName,
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ",
            12,
            () => {
                // Cancelled - do nothing
            },
            (string newName) => {
                if (!string.IsNullOrWhiteSpace(newName))
                {
                    playerName = newName;
                    PlayerPrefsManager.SavePlayerName(playerName);
                    UpdateNameUI();
                }
            }
        );
    }

    public string GetPlayerName() => playerName;
}
