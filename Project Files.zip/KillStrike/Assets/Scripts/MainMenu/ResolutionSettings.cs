using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class ResolutionSettings : MonoBehaviour
{
    [SerializeField] private TMP_Dropdown resolutionDropdown;
    [SerializeField] private Toggle fullscreenToggle;

    private List<Resolution> filteredResolutions = new List<Resolution>();
    private int selectedResolutionIndex = 0;

    void OnEnable()
    {
        PopulateResolutionOptions();

        resolutionDropdown.onValueChanged.AddListener(OnResolutionChanged);
        fullscreenToggle.onValueChanged.AddListener(OnFullscreenToggled);
    }

    void PopulateResolutionOptions()
    {
        resolutionDropdown.ClearOptions();
        Resolution[] allRes = Screen.resolutions;
        filteredResolutions.Clear();

        HashSet<Vector2Int> uniqueResolutions = new HashSet<Vector2Int>();
        List<string> options = new List<string>();

        for (int i = 0; i < allRes.Length; i++)
        {
            Resolution res = allRes[i];
            float aspect = (float)res.width / res.height;
            Vector2Int resKey = new Vector2Int(res.width, res.height);

            if (Mathf.Abs(aspect - (16f / 9f)) < 0.01f && uniqueResolutions.Add(resKey))
            {
                string resText = allRes[i].width + " x " + allRes[i].height;
                options.Add(resText);
                filteredResolutions.Add(allRes[i]);
            }
        }

        var (currentWidth, currentHeight, _) = PlayerPrefsManager.GetResolution();

        selectedResolutionIndex = 0;
        for (int i = 0; i < filteredResolutions.Count; i++)
        {
            if (filteredResolutions[i].width == currentWidth &&
                filteredResolutions[i].height == currentHeight)
            {
                selectedResolutionIndex = i;
                break;
            }
        }

        resolutionDropdown.AddOptions(options);
        resolutionDropdown.value = selectedResolutionIndex;
        resolutionDropdown.RefreshShownValue();

        fullscreenToggle.isOn = PlayerPrefsManager.GetResolution().fullscreen;
    }

    void OnResolutionChanged(int index)
    {
        selectedResolutionIndex = index;
        Resolution res = filteredResolutions[index];
        SetResolution(res.width, res.height, fullscreenToggle.isOn);
    }

    void OnFullscreenToggled(bool isFullscreen)
    {
        Resolution res = filteredResolutions[resolutionDropdown.value];
        SetResolution(res.width, res.height, isFullscreen);
    }

    private void SetResolution(int width, int height, bool fullscreen)
    {
        Screen.SetResolution(width, height, fullscreen);
        PlayerPrefsManager.SaveResolution(width, height, fullscreen);
    }
}
