using UnityEngine;

public static class PlayerPrefsManager
{
    // Player name keys
    private const string PlayerNameKey = "PlayerName";

    // Audio keys
    private const string MasterVolumeKey = "MasterVolume";
    private const string MusicVolumeKey = "MusicVolume";
    private const string SFXVolumeKey = "SFXVolume";

    // Resolution keys
    private const string ResolutionWidthKey = "ResolutionWidth";
    private const string ResolutionHeightKey = "ResolutionHeight";
    private const string FullscreenKey = "Fullscreen";

    // Player name methods
    public static void SavePlayerName(string name)
    {
        PlayerPrefs.SetString(PlayerNameKey, name);
        PlayerPrefs.Save();
    }

    public static string GetPlayerName()
    {
        if (!PlayerPrefs.HasKey(PlayerNameKey))
        {
            string defaultName = "Player" + UnityEngine.Random.Range(1000, 9999);
            SavePlayerName(defaultName);  // Save it so it persists
            return defaultName;
        }

        return PlayerPrefs.GetString(PlayerNameKey);
    }

    public static bool HasPlayerName()
    {
        return PlayerPrefs.HasKey(PlayerNameKey);
    }

    // Audio methods
    public static void SaveMasterVolume(float value)
    {
        PlayerPrefs.SetFloat(MasterVolumeKey, value);
        PlayerPrefs.Save();
    }

    public static void SaveMusicVolume(float value)
    {
        PlayerPrefs.SetFloat(MusicVolumeKey, value);
        PlayerPrefs.Save();
    }

    public static void SaveSFXVolume(float value)
    {
        PlayerPrefs.SetFloat(SFXVolumeKey, value);
        PlayerPrefs.Save();
    }

    public static float GetMasterVolume(float defaultValue = 20f)
    {
        return PlayerPrefs.GetFloat(MasterVolumeKey, defaultValue);
    }

    public static float GetMusicVolume(float defaultValue = 20f)
    {
        return PlayerPrefs.GetFloat(MusicVolumeKey, defaultValue);
    }

    public static float GetSFXVolume(float defaultValue = 20f)
    {
        return PlayerPrefs.GetFloat(SFXVolumeKey, defaultValue);
    }

    // Resolution methods
    public static void SaveResolution(int width, int height, bool fullscreen)
    {
        PlayerPrefs.SetInt(ResolutionWidthKey, width);
        PlayerPrefs.SetInt(ResolutionHeightKey, height);
        PlayerPrefs.SetInt(FullscreenKey, fullscreen ? 1 : 0);
        PlayerPrefs.Save();
    }

    public static (int width, int height, bool fullscreen) GetResolution()
    {
        if (!HasResolution())
        {
            Resolution defaultRes = GetHighestSupportedResolution();
            return (defaultRes.width, defaultRes.height, true);
        }

        int width = PlayerPrefs.GetInt(ResolutionWidthKey, -1);
        int height = PlayerPrefs.GetInt(ResolutionHeightKey, -1);
        bool fullscreen = PlayerPrefs.GetInt(FullscreenKey, 0) == 1;
        return (width, height, fullscreen);
    }

    public static bool HasResolution()
    {
        return PlayerPrefs.HasKey(ResolutionWidthKey) &&
               PlayerPrefs.HasKey(ResolutionHeightKey);
    }

    private static Resolution GetHighestSupportedResolution()
    {
        Resolution[] allRes = Screen.resolutions;
        Resolution highestRes = allRes[0];

        foreach (Resolution res in allRes)
        {
            float aspect = (float)res.width / res.height;
            if (Mathf.Abs(aspect - (16f / 9f)) < 0.01f)
            {
                if (res.width > highestRes.width ||
                   (res.width == highestRes.width && res.height > highestRes.height))
                {
                    highestRes = res;
                }
            }
        }

        return highestRes;
    }

    // Clear All Preferences
    public static void ClearAll()
    {
        PlayerPrefs.DeleteAll();
        PlayerPrefs.Save();
    }
}
