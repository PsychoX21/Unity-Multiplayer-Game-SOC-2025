using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class AudioSettings : MonoBehaviour
{
    public AudioMixer mixer;
    public Slider masterSlider;
    public Slider musicSlider;
    public Slider sfxSlider;

    void OnEnable()
    {
        // Initialize sliders with saved values
        masterSlider.value = PlayerPrefsManager.GetMasterVolume();
        musicSlider.value = PlayerPrefsManager.GetMusicVolume();
        sfxSlider.value = PlayerPrefsManager.GetSFXVolume();

        // Apply initial values
        SetMasterVolume(PlayerPrefsManager.GetMasterVolume());
        SetMusicVolume(PlayerPrefsManager.GetMusicVolume());
        SetSFXVolume(PlayerPrefsManager.GetSFXVolume());
    }

    public void SetMasterVolume(float value)
    {
        // Convert 0-20 range to logarithmic scale
        float volume = value > 0 ? Mathf.Log10(value / 20f) * 20f : -80f;
        mixer.SetFloat("MasterVolume", volume);
        PlayerPrefsManager.SaveMasterVolume(value);
    }

    public void SetMusicVolume(float value)
    {
        float volume = value > 0 ? Mathf.Log10(value / 20f) * 20f : -80f;
        mixer.SetFloat("MusicVolume", volume);
        PlayerPrefsManager.SaveMusicVolume(value);
    }

    public void SetSFXVolume(float value)
    {
        float volume = value > 0 ? Mathf.Log10(value / 20f) * 20f : -80f;
        mixer.SetFloat("SFXVolume", volume);
        PlayerPrefsManager.SaveSFXVolume(value);
    }
}