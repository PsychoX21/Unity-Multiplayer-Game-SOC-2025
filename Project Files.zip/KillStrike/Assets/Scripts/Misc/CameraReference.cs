using UnityEngine;
using Unity.Cinemachine;

public class CameraReference : MonoBehaviour
{
    public static CinemachineCamera Instance { get; private set; }

    private void Awake()
    {
        Instance = GetComponent<CinemachineCamera>();
    }
}
