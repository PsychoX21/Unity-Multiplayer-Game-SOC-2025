using UnityEngine;

[RequireComponent(typeof(Camera))]
public class CameraLetterbox : MonoBehaviour
{
    public float targetAspect = 16f / 9f;

    void Start()
    {
        ApplyLetterbox();
    }

    void ApplyLetterbox()
    {
        float screenAspect = (float)Screen.width / Screen.height;
        float scale = screenAspect / targetAspect;

        Camera cam = GetComponent<Camera>();
        Rect rect = new Rect();

        if (scale < 1f)
        {
            rect.width = 1f;
            rect.height = scale;
            rect.x = 0;
            rect.y = (1f - scale) / 2f;
        }
        else
        {
            float invScale = 1f / scale;
            rect.width = invScale;
            rect.height = 1f;
            rect.x = (1f - invScale) / 2f;
            rect.y = 0;
        }

        cam.rect = rect;
    }

    void Update()
    {
        if (Screen.width != prevW || Screen.height != prevH)
        {
            prevW = Screen.width;
            prevH = Screen.height;
            ApplyLetterbox();
        }
    }

    int prevW = 0;
    int prevH = 0;
}
