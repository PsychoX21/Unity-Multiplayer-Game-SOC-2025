using UnityEngine;

public class UIPersistent : MonoBehaviour
{
    private static UIPersistent _instance;

    private void Awake()
    {
        // Check if another instance already exists
        if (_instance != null && _instance != this)
        {
            Debug.LogWarning("Duplicate UIPersistent detected - destroying duplicate");
            Destroy(gameObject);
            return;
        }

        _instance = this;

        if (transform.parent != null)
        {
            Debug.LogWarning("UIPersistent must be on the root GameObject, not a child!");
        }

        DontDestroyOnLoad(gameObject);
    }

    private void OnDestroy()
    {
        if (_instance == this)
        {
            _instance = null;
        }
    }
}
