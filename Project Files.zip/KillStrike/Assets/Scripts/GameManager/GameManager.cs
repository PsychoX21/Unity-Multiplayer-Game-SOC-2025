using Unity.Netcode;
using UnityEngine;
using System.Collections;
using TMPro;
using UnityEngine.SceneManagement;
using System.Linq;

public class GameManager : NetworkBehaviour
{
    public static GameManager Instance;

    public NetworkVariable<float> gameTimer = new(10f);
    public NetworkVariable<bool> gameStarted = new(false);
    public NetworkVariable<bool> gameEnded = new(false);
    public TextMeshProUGUI countdownText;
    private bool _countdownStarted;

    private bool _hasSentFightRpc;

    public NetworkVariable<float> matchTimer = new(300f);
    public TextMeshProUGUI matchTimerText;

    private NetworkList<ulong> connectedPlayers = new();

    private bool _musicInitialized;

    private bool _isQuitting = false;

    private void Awake()
    {
        Debug.Log("GameManager Awake");

        // Singleton pattern
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            Debug.Log("GameManager instance created");
        }
        else
        {
            Debug.Log("Duplicate GameManager destroyed");
            Destroy(gameObject);
        }
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.name != "GameWorld")
        {
            CleanUp();
        }
    }

    public override void OnNetworkSpawn()
    {
        Debug.Log("GameManager OnNetworkSpawn");

        base.OnNetworkSpawn();

        // Find UI text if not assigned
        if (countdownText == null)
        {
            Debug.Log("Searching for countdown text...");
            var textObj = GameObject.FindGameObjectWithTag("CountdownText");
            if (textObj != null)
            {
                countdownText = textObj.GetComponent<TextMeshProUGUI>();
                Debug.Log("Countdown text found");
            }
            else
            {
                Debug.LogWarning("Countdown text not found!");
            }
        }

        if (matchTimerText == null)
        {
            matchTimerText = GameObject.FindGameObjectWithTag("MatchTimerText")?.GetComponent<TextMeshProUGUI>();
        }

        matchTimer.OnValueChanged += OnMatchTimerChanged;
        OnMatchTimerChanged(0, matchTimer.Value);

        gameTimer.OnValueChanged += UpdateCountdownDisplay;
        UpdateCountdownDisplay(0, gameTimer.Value);

        if (IsServer && !_countdownStarted)
        {
            Debug.Log("Server starting countdown");
            StartCoroutine(GameStartCountdown());
            _countdownStarted = true;
        }

        if (gameStarted.Value)
        {
            Debug.Log("Late joiner detected");
            StartCoroutine(HandleLateJoin());
        }

        if (IsServer)
        {
            connectedPlayers.Add(NetworkObject.OwnerClientId);
        }

        NetworkManager.Singleton.OnClientDisconnectCallback += HandleClientDisconnect;
    }

    private IEnumerator HandleLateJoin()
    {
        // Wait for scene to stabilize
        yield return new WaitForSeconds(0.5f);

        if (countdownText != null)
        {
            countdownText.text = "FIGHT!";
            StartCoroutine(ClientHideTextAfterDelay(countdownText, 2f));
        }

        UpdateMatchTimerDisplay();
    }

    private void OnMatchTimerChanged(float oldValue, float newValue)
    {
        UpdateMatchTimerDisplay();
    }

    private IEnumerator MatchCountdown()
    {
        while (matchTimer.Value > 0 && gameStarted.Value)
        {
            matchTimer.Value -= Time.deltaTime;
            UpdateMatchTimerDisplay();
            yield return null;
        }

        if (IsServer)
        {
            EndGameServerRpc();
        }
    }

    private void UpdateMatchTimerDisplay()
    {
        if (matchTimerText == null)
        {
            matchTimerText = GameObject.FindGameObjectWithTag("MatchTimerText")?.GetComponent<TextMeshProUGUI>();
            if (matchTimerText == null) return;
        }

        int minutes = Mathf.FloorToInt(matchTimer.Value / 60);
        int seconds = Mathf.FloorToInt(matchTimer.Value % 60);
        matchTimerText.text = $"{minutes:00}:{seconds:00}";
    }

    [ServerRpc]
    private void EndGameServerRpc()
    {
        gameStarted.Value = false;
        gameEnded.Value = true;
        if (_musicInitialized)
        {
            MusicManager.Instance.PlayGameOverMusic();
        }
        GameOverClientRpc();
    }

    [ClientRpc]
    private void GameOverClientRpc()
    {
        UIManager.Instance.ShowGameOverPanel();
    }

    private IEnumerator GameStartCountdown()
    {
        Debug.Log("Countdown coroutine started");

        // Wait for scene to stabilize
        yield return new WaitForSeconds(1f);

        Debug.Log($"Connected clients: {NetworkManager.Singleton.ConnectedClients.Count}");

        // Wait until at least 2 players
        while (NetworkManager.Singleton.ConnectedClients.Count < 2)
        {
            Debug.Log("Waiting for players...");
            yield return new WaitForSeconds(1f);
        }

        Debug.Log("Minimum players reached, starting countdown");

        yield return EnsureMusicManagerReady();

        // Start countdown
        float timer = 10f;
        if (IsServer && MusicManager.Instance != null)
        {
            MusicManager.Instance.PlayCountdownMusic();
        }
        else
        {
            Debug.LogWarning("MusicManager not available for countdown");
        }
        while (timer > 0)
        {
            gameTimer.Value = timer;
            Debug.Log($"Countdown: {timer}");
            timer -= 1f;
            yield return new WaitForSeconds(1f);
        }

        Debug.Log("Countdown finished, starting game");

        // Start game
        gameTimer.Value = 0;
        gameStarted.Value = true;
        _hasSentFightRpc = false;
        ForceFightUiUpdate();
        StartGameClientRpc();

        if (IsServer && MusicManager.Instance != null)
        {
            MusicManager.Instance.PlayMainGameMusic();
        }
        else
        {
            Debug.LogWarning("MusicManager not available for Main Game Music");
        }

        if (IsServer)
        {
            StartCoroutine(MatchCountdown());
        }
    }

    private IEnumerator EnsureMusicManagerReady()
    {
        int attempts = 0;
        while (MusicManager.Instance == null && attempts < 10)
        {
            Debug.Log("Waiting for MusicManager Instance...");
            attempts++;
            yield return new WaitForSeconds(1f);
        }

        if (MusicManager.Instance == null)
        {
            Debug.LogError("MusicManager Instance not found after waiting!");
        }
        else
        {
            Debug.Log("MusicManager instance confirmed");
            _musicInitialized = true;
        }
    }

    private void ForceFightUiUpdate()
    {
        if (countdownText != null)
        {
            countdownText.text = "FIGHT!";
            StartCoroutine(HideTextAfterDelay(2f));
        }

        // Also update NetworkVariable for clients
        gameStarted.Value = true;
    }

    [ClientRpc]
    private void StartGameClientRpc()
    {
        if (_hasSentFightRpc) return;
        _hasSentFightRpc = true;

        Debug.Log("StartGameClientRpc received");

        if (!IsHost && _musicInitialized && MusicManager.Instance != null)
        {
            MusicManager.Instance.PlayMainGameMusic();
        }

        TextMeshProUGUI clientText = countdownText;
        if (clientText == null)
        {
            var textObj = GameObject.FindGameObjectWithTag("CountdownText");
            if (textObj) clientText = textObj.GetComponent<TextMeshProUGUI>();
        }

        if (clientText != null)
        {
            clientText.text = "FIGHT!";
            StartCoroutine(ClientHideTextAfterDelay(clientText, 2f));
        }
    }

    private IEnumerator ClientHideTextAfterDelay(TextMeshProUGUI textElement, float delay)
    {
        yield return new WaitForSeconds(delay);
        if (textElement != null)
            textElement.gameObject.SetActive(false);
    }

    private void UpdateCountdownDisplay(float oldTime, float newTime)
    {
        // Only update if we haven't shown FIGHT! yet
        if (gameStarted.Value) return;

        if (countdownText == null) return;

        if (newTime > 0)
        {
            countdownText.text = Mathf.CeilToInt(newTime).ToString();
        }
        else
        {
            countdownText.text = "WAITING...";
        }
    }

    private IEnumerator HideTextAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        if (countdownText != null)
            countdownText.gameObject.SetActive(false);
    }

    private void LateUpdate()
    {
        if (!IsClient) return;

        // Force update if game started but UI still shows waiting
        if (gameStarted.Value &&
            countdownText != null &&
            countdownText.text != "FIGHT!")
        {
            countdownText.text = "FIGHT!";
            StartCoroutine(ClientHideTextAfterDelay(countdownText, 2f));
        }
    }

    public void LeaveGame()
    {
        if (_isQuitting) return;
        _isQuitting = true;

        StartCoroutine(LeaveGameSequence());
    }

    private IEnumerator LeaveGameSequence()
    {
        Debug.Log("Starting leave game sequence");

        // Shutdown network first
        if (NetworkManager.Singleton != null && NetworkManager.Singleton.IsListening)
        {
            Debug.Log("Shutting down network");

            if (IsServer)
            {
                // Notify clients first
                ShutdownNotificationClientRpc();
                yield return new WaitForSeconds(1f); // Give clients time to react
            }

            NetworkManager.Singleton.Shutdown();
        }

        // Load main menu
        SceneManager.LoadScene("MainMenu");

        // Clean up managers
        CleanUpManagers();
    }

    private void CleanUpManagers()
    {
        Debug.Log("Cleaning up managers");

        // Destroy NetworkManager if exists
        var networkManager = FindFirstObjectByType<NetworkManager>();
        if (networkManager != null)
        {
            Debug.Log("Destroying NetworkManager");
            Destroy(networkManager.gameObject);
        }

        if (UIManager.Instance != null)
        {
            Debug.Log("Destroying UIManager");
            Destroy(UIManager.Instance.gameObject);
        }

        // Destroy GameManager
        if (Instance == this)
        {
            Debug.Log("Destroying GameManager");
            Destroy(gameObject);
        }

        // Destroy MusicManager
        if (MusicManager.Instance != null)
        {
            Debug.Log("Destroying MusicManager");
            Destroy(MusicManager.Instance.gameObject);
        }
    }

    private void CleanUp()
    {
        // Clear all event subscriptions
        SceneManager.sceneLoaded -= OnSceneLoaded;

        if (NetworkManager.Singleton != null)
        {
            NetworkManager.Singleton.OnClientDisconnectCallback -= HandleClientDisconnect;
        }

        // Destroy this instance
        if (Instance == this)
        {
            Instance = null;
        }

        Destroy(gameObject);
    }

    [ClientRpc]
    private void ShutdownNotificationClientRpc()
    {
        if (!IsServer) // Clients should clean themselves up
        {
            Debug.Log("Client received shutdown notification");
            StartCoroutine(ClientLeaveSequence());
        }
    }

    private IEnumerator ClientLeaveSequence()
    {
        if (_isQuitting) yield break;
        _isQuitting = true;

        Debug.Log("Client starting leave sequence");

        SceneManager.LoadScene("MainMenu");
        CleanUpManagers();
    }

    // In GameManager.cs
    private void HandleClientDisconnect(ulong clientId)
    {
        if (IsServer && !gameEnded.Value)
        {
            Debug.Log($"Client {clientId} disconnected");

            if (connectedPlayers.Contains(clientId))
            {
                connectedPlayers.Remove(clientId);
            }

            // Directly despawn player object
            NetworkObject playerObject = NetworkManager.Singleton.SpawnManager.GetPlayerNetworkObject(clientId);
            if (playerObject != null)
            {
                Debug.Log($"Despawning player object for client {clientId}");
                playerObject.Despawn();
            }
            else
            {
                Debug.LogWarning($"Player object for client {clientId} not found - may already be despawned");
            }

            // Update leaderboards immediately
            StartCoroutine(DelayedLeaderboardUpdate());

            // End game if not enough players
            if (gameStarted.Value && NetworkManager.Singleton.ConnectedClients.Count < 2)
            {
                EndGameServerRpc();
            }
        }
        else if (clientId == NetworkManager.Singleton.LocalClientId)
        {
            Debug.Log("We were disconnected");
            StartCoroutine(ClientLeaveSequence());
        }
    }

    private IEnumerator DelayedLeaderboardUpdate()
    {
        // Wait for despawn to complete
        yield return new WaitForSeconds(0.5f);

        if (UIManager.Instance != null)
        {
            UIManager.Instance.UpdateLeaderboard(UIManager.Instance.pauseLeaderboardContent);
            UIManager.Instance.UpdateLeaderboard(UIManager.Instance.gameOverLeaderboardContent);
        }
    }

    [ClientRpc]
    private void SyncGameStateClientRpc(ClientRpcParams rpcParams = default)
    {
        if (!IsServer && gameStarted.Value)
        {
            // Force fight UI for late joiners
            if (countdownText != null)
            {
                countdownText.text = "FIGHT!";
                StartCoroutine(ClientHideTextAfterDelay(countdownText, 2f));
            }

            // Sync match timer
            UpdateMatchTimerDisplay();
        }
    }

    public void OnPlayerJoined()
    {
        if (IsServer && gameStarted.Value)
        {
            SyncGameStateClientRpc(new ClientRpcParams
            {
                Send = new ClientRpcSendParams
                {
                    TargetClientIds = new ulong[] { NetworkManager.Singleton.ConnectedClientsIds.Last() }
                }
            });
        }
    }

    public override void OnDestroy()
    {
        base.OnDestroy();

        // Clean up static instance
        if (Instance == this)
        {
            Instance = null;
        }
    }
}