using Unity.Netcode;
using UnityEngine;

public class GameManagerSpawner : MonoBehaviour
{
    [SerializeField] private GameObject gameManagerPrefab;
    private bool _hasSpawned;

    private void Start()
    {
        // Try spawning immediately
        TrySpawnGameManager();

        // Also register for network events
        if (NetworkManager.Singleton != null)
        {
            NetworkManager.Singleton.OnServerStarted += TrySpawnGameManager;
        }
    }

    private void TrySpawnGameManager()
    {
        // Only server can spawn
        if (!NetworkManager.Singleton.IsServer || _hasSpawned) return;

        // Check if GameManager already exists
        if (GameObject.FindFirstObjectByType<GameManager>() != null) return;

        Debug.Log("Attempting to spawn GameManager...");

        // Instantiate and spawn
        GameObject gm = Instantiate(gameManagerPrefab);
        NetworkObject netObj = gm.GetComponent<NetworkObject>();

        if (netObj == null)
        {
            Debug.LogError("GameManager prefab is missing NetworkObject component!");
            Destroy(gm);
            return;
        }

        netObj.Spawn();
        netObj.DontDestroyWithOwner = true;
        _hasSpawned = true;

        Debug.Log("GameManager spawned successfully!");
    }

    private void OnDestroy()
    {
        if (NetworkManager.Singleton != null)
        {
            NetworkManager.Singleton.OnServerStarted -= TrySpawnGameManager;
        }
    }
}