using TMPro;
using UnityEngine;

public class LeaderboardEntry : MonoBehaviour
{
    public TextMeshProUGUI rankText;
    public TextMeshProUGUI nameText;
    public TextMeshProUGUI killsText;
    public TextMeshProUGUI deathsText;

    // Define rank colors
    private static readonly Color GoldColor = new Color(1f, 0.843f, 0f);    // #FFD700
    private static readonly Color SilverColor = new Color(0.753f, 0.753f, 0.753f);  // #C0C0C0
    private static readonly Color BronzeColor = new Color(0.804f, 0.498f, 0.196f); // #CD7F32

    public void Setup(int rank, string name, int kills, int deaths)
    {
        rankText.text = rank.ToString();
        nameText.text = name;
        killsText.text = kills.ToString();
        deathsText.text = deaths.ToString();

        SetRankColor(rank);
    }

    private void SetRankColor(int rank)
    {
        switch (rank)
        {
            case 1:
                rankText.color = GoldColor;
                break;
            case 2:
                rankText.color = SilverColor;
                break;
            case 3:
                rankText.color = BronzeColor;
                break;
            default:
                rankText.color = Color.white;
                break;
        }
    }

    public void HighlightLocalPlayer()
    {
        nameText.color = Color.black;
    }
}