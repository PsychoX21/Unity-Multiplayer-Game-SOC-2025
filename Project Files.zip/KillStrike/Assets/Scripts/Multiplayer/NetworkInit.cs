using UnityEngine;
using Unity.Netcode;
using UnityEngine.SceneManagement;

public class NetworkInit : MonoBehaviour
{
    private void Awake()
    {
        // Only persist in LobbyScene and GameWorld
        if (SceneManager.GetActiveScene().name != "MainMenu")
        {
            DontDestroyOnLoad(gameObject);
            Debug.Log($"NetworkInit will persist {gameObject.name}");
        }
    }

    private void OnDestroy()
    {
        Debug.Log($"NetworkInit destroyed for {gameObject.name}");
    }
}