using TMPro;
using UnityEngine;
using System.Collections;

public class KillfeedEntry : MonoBehaviour
{
    public TextMeshProUGUI killText;
    public Color EntryColor { get; private set; }
    public Coroutine ClearCoroutine;

    public string Text
    {
        get => killText.text;
        set => killText.text = value;
    }

    public void Set(string text, Color color)
    {
        EntryColor = color;

        killText.text = text;
        killText.color = new Color(color.r, color.g, color.b, 0);
        StartCoroutine(FadeIn(color));
    }


    private IEnumerator FadeIn(Color targetColor)
    {
        float duration = 0.5f;
        float elapsed = 0;

        while (elapsed < duration)
        {
            float alpha = Mathf.Lerp(0, 1, elapsed / duration);
            killText.color = new Color(targetColor.r, targetColor.g, targetColor.b, alpha);
            elapsed += Time.deltaTime;
            yield return null;
        }
        killText.color = new Color(targetColor.r, targetColor.g, targetColor.b, 1);
    }

    public void CopyFrom(KillfeedEntry other, MonoBehaviour context)
    {
        Text = other.Text;
        killText.color = new Color(other.EntryColor.r, other.EntryColor.g, other.EntryColor.b, other.EntryColor.a);

        if (ClearCoroutine != null)
            context.StopCoroutine(ClearCoroutine);

        ClearCoroutine = other.ClearCoroutine;
    }
}