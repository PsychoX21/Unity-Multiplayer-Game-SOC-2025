using UnityEngine;
using TMPro;
using System.Collections.Generic;
using System.Collections;
using Unity.Netcode;
using System.Linq;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    [Header("Panels")]
    public GameObject pausePanel;
    public GameObject deathPanel;
    public GameObject gameOverPanel;

    [Header("Text Elements")]
    public TextMeshProUGUI respawnTimerText;
    public TextMeshProUGUI matchTimerText;

    [Header("Leaderboards")]
    public Transform pauseLeaderboardContent;
    public Transform gameOverLeaderboardContent;

    [Header("Prefabs")]
    public GameObject leaderboardEntryPrefab;

    [Header("Killfeed")]
    public KillfeedEntry[] killfeedEntries;
    private readonly Queue<string> killMessages = new();

    private Coroutine respawnCountdownCoroutine;

    public Button ExitButton1;
    public Button ExitButton2;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else Destroy(gameObject);
    }

    private void OnDestroy()
    {
        if (Instance == this)
        {
            Instance = null;
            Debug.Log("UIManager instance destroyed");
        }
    }

    private void Update()
    {
        HandlePauseInput();
    }

    private void HandlePauseInput()
    {
        if (UserInput.instance.controls.Menu.Exit.WasPressedThisFrame())
        {
            if (gameOverPanel.activeSelf)
            {
                return;
            }

            else if (deathPanel.activeSelf)
            {
                deathPanel.SetActive(false);
                TogglePauseMenu(true);
            }
            else if (pausePanel.activeSelf)
            {
                TogglePauseMenu(false);
            }
            else
            {
                TogglePauseMenu(true);
            }
        }
    }

    public void TogglePauseMenu(bool show)
    {
        if (gameOverPanel.activeSelf) return;

        pausePanel.SetActive(show);
        if (show) UpdateLeaderboard(pauseLeaderboardContent);
    }

    public void ShowDeathPanel()
    {
        if (pausePanel.activeSelf) pausePanel.SetActive(false);

        if (deathPanel != null) deathPanel.SetActive(true);
        if (respawnCountdownCoroutine != null)
        {
            StopCoroutine(respawnCountdownCoroutine);
        }
        respawnCountdownCoroutine = StartCoroutine(RespawnCountdown(5f));
    }

    private IEnumerator RespawnCountdown(float time)
    {
        float timer = time;
        while (timer > 0)
        {
            if (respawnTimerText != null)
                respawnTimerText.text = $"RESPAWN IN: {Mathf.CeilToInt(timer)}";
            timer -= Time.deltaTime;
            yield return null;
        }
        if (deathPanel != null) deathPanel.SetActive(false);
        if (pausePanel != null) pausePanel.SetActive(false);
    }

    public void UpdateLeaderboard(Transform contentParent)
    {
        if (contentParent == null) return;

        // Clear existing
        foreach (Transform child in contentParent)
        {
            Destroy(child.gameObject);
        }

        // Get and sort players
        PlayerStats[] players = FindObjectsByType<PlayerStats>(FindObjectsInactive.Exclude, FindObjectsSortMode.None).Where(p => p != null && p.gameObject != null).ToArray();

        // Sort players by: 1. Kills (descending), 2. Deaths (ascending), 3. PlayerName (ascending)
        System.Array.Sort(players, (a, b) =>
        {
            // First priority: Higher kills come first
            int killComparison = b.Kills.Value.CompareTo(a.Kills.Value);
            if (killComparison != 0) return killComparison;

            // Second priority: Lower deaths come first
            int deathComparison = a.Deaths.Value.CompareTo(b.Deaths.Value);
            if (deathComparison != 0) return deathComparison;

            // Third priority: Alphabetical name order
            return string.Compare(
                a.playerName.Value.ToString(),
                b.playerName.Value.ToString(),
                System.StringComparison.OrdinalIgnoreCase
            );
        });

        // Identify Local Player
        PlayerStats localplayer = null;
        foreach (PlayerStats player in players)
        {
            if (player.GetComponent<NetworkObject>().IsLocalPlayer)
            {
                localplayer = player;
                break;
            }
        }

        // Create entries
        for (int i = 0; i < players.Length; i++)
        {
            var entry = Instantiate(leaderboardEntryPrefab, contentParent);
            var entryScript = entry.GetComponent<LeaderboardEntry>();
            if (entryScript != null)
            {
                entryScript.Setup(
                    i + 1,
                    players[i].playerName.Value.ToString(),
                    players[i].Kills.Value,
                    players[i].Deaths.Value
                );

                if (localplayer != null && players[i] == localplayer) 
                {
                    entryScript.HighlightLocalPlayer();
                }
            }
        }
    }

    public void ShowGameOverPanel()
    {
        if (deathPanel != null) deathPanel.SetActive(false);
        if (pausePanel != null) pausePanel.SetActive(false);

        if (respawnCountdownCoroutine != null)
        {
            StopCoroutine(respawnCountdownCoroutine);
            respawnCountdownCoroutine = null;
        }

        if (gameOverPanel != null)
        {
            gameOverPanel.SetActive(true);
            UpdateLeaderboard(gameOverLeaderboardContent);

            foreach (PlayerMovement player in FindObjectsByType<PlayerMovement>(FindObjectsSortMode.None))
            {
                player.enabled = false;
            }
        }
    }

    public void AddKillfeed(string killer, string victim, ulong killerId, ulong victimId)
    {
        Color feedColor;
        if (NetworkManager.Singleton.LocalClientId == killerId)
        {
            feedColor = Color.green;
        } else if (NetworkManager.Singleton.LocalClientId == victimId) 
        {
            feedColor = Color.red;
        } else
        {
            feedColor = Color.white;
        }

        // Shift up if feed is full (bottom not empty)
        if (!string.IsNullOrEmpty(killfeedEntries[killfeedEntries.Length - 1].Text))
        {
            for (int i = 0; i < killfeedEntries.Length - 1; i++)
            {
                killfeedEntries[i].CopyFrom(killfeedEntries[i + 1], this);
            }
        }

        // Add new kill to last slot
        int lastIndex = killfeedEntries.Length - 1;
        killfeedEntries[lastIndex].Set($"{killer} killed {victim}", feedColor);

        // Cancel old clear coroutine if exists
        if (killfeedEntries[lastIndex].ClearCoroutine != null)
            StopCoroutine(killfeedEntries[lastIndex].ClearCoroutine);

        // Start new clear coroutine for this slot
        killfeedEntries[lastIndex].ClearCoroutine = StartCoroutine(ClearKillfeedAfterDelay(lastIndex, 5f));
    }

    private IEnumerator ClearKillfeedAfterDelay(int index, float delay)
    {
        yield return new WaitForSeconds(delay);

        for (int i = index; i < killfeedEntries.Length - 1; i++)
        {
            killfeedEntries[i].CopyFrom(killfeedEntries[i + 1], this);
        }

        // Clear last slot
        int lastIndex = killfeedEntries.Length - 1;
        killfeedEntries[lastIndex].Text = "";
        killfeedEntries[lastIndex].ClearCoroutine = null;
    }

    public void LeaveGame()
    {
        Debug.Log("Exit button clicked");

        ExitButton1.interactable = false;
        ExitButton2.interactable = false;

        if (GameManager.Instance != null)
        {
            GameManager.Instance.LeaveGame();
        }
        else
        {
            SceneManager.LoadScene("MainMenu");
        }
    }
}