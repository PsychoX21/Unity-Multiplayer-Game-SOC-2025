using UnityEngine;
using Unity.Services.Authentication;
using Unity.Services.Core;
using System;
using System.Threading.Tasks;

public class AuthenticationManager : MonoBehaviour
{
    public static AuthenticationManager Instance { get; private set; }

    public string PlayerId { get; private set; }
    public string PlayerName => PlayerPrefsManager.GetPlayerName();

    private async void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            await AuthenticatePlayerAsync();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private async Task AuthenticatePlayerAsync()
    {
        try
        {
            await UnityServices.InitializeAsync();

            if (!AuthenticationService.Instance.IsSignedIn)
            {
                await AuthenticationService.Instance.SignInAnonymouslyAsync();
                Debug.Log($"Signed in anonymously. PlayerID: {AuthenticationService.Instance.PlayerId}");
            }

            PlayerId = AuthenticationService.Instance.PlayerId;

            AuthenticationService.Instance.SignedIn += () =>
            {
                Debug.Log($"Signed in as: {PlayerId}");
            };

            AuthenticationService.Instance.SignInFailed += (err) =>
            {
                Debug.LogError($"Sign-in failed: {err}");
            };
        }
        catch (Exception e)
        {
            Debug.LogError($"Authentication error: {e.Message}");
        }
    }
}
