using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class SelectedObjectManager : MonoBehaviour
{
    public static SelectedObjectManager Instance { get; private set; }

    private Dictionary<string, GameObject> panelLastSelected = new Dictionary<string, GameObject>();
    private GameObject currentSelectedObject;
    private GameObject beforeInputWindowSelected;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void Update()
    {
        GameObject currentSelected = EventSystem.current.currentSelectedGameObject;
        if (currentSelected != null && currentSelected != currentSelectedObject)
        {
            currentSelectedObject = currentSelected;
        }
    }

    public void SetPanelDefault(string panelName, GameObject defaultSelected)
    {
        if (!panelLastSelected.ContainsKey(panelName))
        {
            panelLastSelected.Add(panelName, defaultSelected);
        }
        else
        {
            panelLastSelected[panelName] = defaultSelected;
        }
    }

    public void RestorePanelSelection(string panelName)
    {
        if (panelLastSelected.ContainsKey(panelName) &&
            panelLastSelected[panelName] != null &&
            panelLastSelected[panelName].activeInHierarchy)
        {
            EventSystem.current.SetSelectedGameObject(panelLastSelected[panelName]);
        }
    }

    public void RememberCurrentSelection()
    {
        beforeInputWindowSelected = currentSelectedObject;
    }

    public void RestorePreInputSelection()
    {
        if (beforeInputWindowSelected != null &&
            beforeInputWindowSelected.activeInHierarchy)
        {
            EventSystem.current.SetSelectedGameObject(beforeInputWindowSelected);
        }
        beforeInputWindowSelected = null;
    }

    public void UpdateSelectedForPanel(string panelName, GameObject selected)
    {
        if (panelLastSelected.ContainsKey(panelName))
        {
            panelLastSelected[panelName] = selected;
        }
    }
}