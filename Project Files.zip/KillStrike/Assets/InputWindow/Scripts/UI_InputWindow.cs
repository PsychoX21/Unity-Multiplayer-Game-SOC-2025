﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;

public class UI_InputWindow : MonoBehaviour {

    private static UI_InputWindow instance;

    private Button okBtn;
    private Button cancelBtn;
    private TextMeshProUGUI titleText;
    private TMP_InputField inputField;
    private Action okAction;
    private Action cancelAction;

    private GameObject lastSelectedObject;

    private void Awake() {
        if (instance != null && instance != this)
        {
            Destroy(gameObject); // Prevent duplicate
            return;
        }

        instance = this;

        okBtn = transform.Find("okBtn").GetComponent<Button>();
        cancelBtn = transform.Find("cancelBtn").GetComponent<Button>();
        titleText = transform.Find("titleText").GetComponent<TextMeshProUGUI>();
        inputField = transform.Find("inputField").GetComponent<TMP_InputField>();

        okBtn.onClick.AddListener(() => okAction());
        cancelBtn.onClick.AddListener(() => cancelAction());

        SetupNavigation();
        Hide();
    }

    private void SetupNavigation()
    {
        // Input Field Navigation
        Navigation inputNav = inputField.navigation;
        inputNav.mode = Navigation.Mode.Explicit;
        inputNav.selectOnDown = okBtn;
        inputField.navigation = inputNav;

        // OK Button Navigation
        Navigation okNav = okBtn.navigation;
        okNav.mode = Navigation.Mode.Explicit;
        okNav.selectOnUp = inputField;
        okNav.selectOnRight = cancelBtn;
        okBtn.navigation = okNav;

        // Cancel Button Navigation
        Navigation cancelNav = cancelBtn.navigation;
        cancelNav.mode = Navigation.Mode.Explicit;
        cancelNav.selectOnUp = inputField;
        cancelNav.selectOnLeft = okBtn;
        cancelBtn.navigation = cancelNav;
    }

    private void Update() {
        if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetKeyDown(KeyCode.JoystickButton0)) {
            okAction();
        }
        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.JoystickButton1)) {
            cancelAction();
        }
    }

    private void Show(string titleString, string inputString, string validCharacters, int characterLimit, Action onCancel, Action<string> onOk) 
    {
        lastSelectedObject = EventSystem.current.currentSelectedGameObject;

        gameObject.SetActive(true);
        transform.SetAsLastSibling();

        UI_Blocker.Show_Static();

        titleText.text = titleString;

        inputField.characterLimit = characterLimit;
        inputField.onValidateInput = (string text, int charIndex, char addedChar) => {
            return ValidateChar(validCharacters, addedChar);
        };

        inputField.text = inputString;
        inputField.Select();
        inputField.ActivateInputField();

        okAction = () => {
            Hide();
            onOk(inputField.text);
        };

        cancelAction = () => {
            Hide();
            onCancel();
        };
    }

    private void Hide() {
        gameObject.SetActive(false);
        UI_Blocker.Hide_Static();

        RestoreSelection();
    }

    private void RestoreSelection()
    {
        if (lastSelectedObject != null && lastSelectedObject.activeInHierarchy)
        {
            EventSystem.current.SetSelectedGameObject(lastSelectedObject);
        }
        lastSelectedObject = null; // Clear reference
    }

    private char ValidateChar(string validCharacters, char addedChar) {
        if (validCharacters.IndexOf(addedChar) != -1) {
            // Valid
            return addedChar;
        } else {
            // Invalid
            return '\0';
        }
    }

    public static void Show_Static(string titleString, string inputString, string validCharacters, int characterLimit, Action onCancel, Action<string> onOk) {
        if (instance == null)
        {
            Debug.LogError("UI_InputWindow is missing! Ensure it's in Main Menu scene and marked DontDestroyOnLoad.");
            return;
        }

        instance.Show(titleString, inputString, validCharacters, characterLimit, onCancel, onOk);
    }

    public static void Show_Static(string titleString, int defaultInt, Action onCancel, Action<int> onOk) {
        instance.Show(titleString, defaultInt.ToString(), "0123456789-", 1, onCancel, 
            (string inputText) => {
                // Try to Parse input string
                if (int.TryParse(inputText, out int _i)) {
                    onOk(_i);
                } else {
                    onOk(defaultInt);
                }
            }
        );
    }
}
